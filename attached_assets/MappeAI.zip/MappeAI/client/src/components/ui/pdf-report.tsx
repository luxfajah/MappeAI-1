import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ReportContent, Competitor } from "@/lib/api";
import { jsPDF } from "jspdf";
import { useToast } from "@/hooks/use-toast";
import { Check, Download, Save } from "lucide-react";
import { useState } from "react";

interface PDFReportProps {
  businessName: string;
  location: string;
  createdAt: Date;
  competitors: Competitor[];
  content: ReportContent;
}

export function PDFReport({ 
  businessName, 
  location,
  createdAt,
  competitors,
  content
}: PDFReportProps) {
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  
  const saveReport = () => {
    toast({
      title: "Report Saved",
      description: "The report has been saved to your reports list.",
    });
  };
  
  const downloadPDF = async () => {
    try {
      setIsGenerating(true);
      
      // Create a new PDF
      const doc = new jsPDF();
      
      // Add title
      doc.setFontSize(24);
      doc.setTextColor(50, 50, 50);
      doc.text(`Análise Competitiva: ${businessName}`, 20, 20);
      
      // Add date and location
      doc.setFontSize(12);
      doc.setTextColor(100, 100, 100);
      const date = new Date(createdAt).toLocaleDateString('pt-BR');
      doc.text(`Gerado em ${date} | Localização: ${location}`, 20, 30);
      
      // Add executive summary
      doc.setFontSize(16);
      doc.setTextColor(50, 50, 50);
      doc.text("Resumo Executivo", 20, 45);
      
      // Add summary text (with word wrapping)
      doc.setFontSize(11);
      doc.setTextColor(70, 70, 70);
      const summaryLines = doc.splitTextToSize(content.executiveSummary, 170);
      doc.text(summaryLines, 20, 55);
      
      let yPos = 55 + (summaryLines.length * 7);
      
      // Competitive Insights
      doc.setFontSize(16);
      doc.setTextColor(50, 50, 50);
      doc.text("Panorama Competitivo", 20, yPos + 10);
      yPos += 20;
      
      // Price range
      doc.setFontSize(12);
      doc.text(`Faixa de Preços: ${content.competitiveInsights.priceRange.currency} ${content.competitiveInsights.priceRange.low}-${content.competitiveInsights.priceRange.high}`, 25, yPos);
      yPos += 10;
      
      // Ratings
      doc.text("Avaliações dos Clientes:", 25, yPos);
      yPos += 8;
      content.competitiveInsights.ratings.forEach(rating => {
        doc.setFontSize(10);
        doc.text(`${rating.competitor}: ${rating.rating} ★`, 30, yPos);
        yPos += 6;
      });
      
      yPos += 5;
      
      // Sales channels
      doc.setFontSize(12);
      doc.text("Canais de Venda Utilizados:", 25, yPos);
      yPos += 8;
      content.competitiveInsights.channelsUsage.forEach(channel => {
        doc.setFontSize(10);
        doc.text(`${channel.channel}: ${channel.percentage}%`, 30, yPos);
        yPos += 6;
      });
      
      // Check if we need a new page
      if (yPos > 250) {
        doc.addPage();
        yPos = 20;
      } else {
        yPos += 15;
      }
      
      // Key Differentiators
      doc.setFontSize(16);
      doc.setTextColor(50, 50, 50);
      doc.text("Principais Diferenciais", 20, yPos);
      yPos += 10;
      
      content.keyDifferentiators.forEach(diff => {
        doc.setFontSize(12);
        doc.text(diff.competitor, 25, yPos);
        yPos += 7;
        
        diff.strengths.forEach(strength => {
          doc.setFontSize(10);
          doc.text(`• ${strength}`, 30, yPos);
          yPos += 6;
        });
        yPos += 5;
        
        // Check if we need a new page
        if (yPos > 270) {
          doc.addPage();
          yPos = 20;
        }
      });
      
      // Recommendations
      doc.setFontSize(16);
      doc.setTextColor(50, 50, 50);
      doc.text("Recomendações Estratégicas", 20, yPos + 5);
      yPos += 15;
      
      content.recommendations.forEach((rec, index) => {
        doc.setFontSize(10);
        const recLines = doc.splitTextToSize(`${index + 1}. ${rec}`, 170);
        doc.text(recLines, 25, yPos);
        yPos += (recLines.length * 6) + 5;
        
        // Check if we need a new page
        if (yPos > 270) {
          doc.addPage();
          yPos = 20;
        }
      });
      
      // Add footer with Chamad Mappe.ia branding
      const pageCount = doc.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(9);
        doc.setTextColor(150, 150, 150);
        doc.text('Gerado por Chamad Mappe.ia', 20, 290);
        doc.text(`Página ${i} de ${pageCount}`, 170, 290);
      }
      
      // Save the PDF
      doc.save(`relatorio-${businessName.replace(/\s+/g, '-')}.pdf`);
      
      // Show success message
      toast({
        title: "Download Successful",
        description: "Your PDF report has been downloaded.",
      });
    } catch (error) {
      console.error("Error generating PDF:", error);
      toast({
        title: "Download Failed",
        description: "There was an error generating your PDF. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  return (
    <div>
      <div className="flex justify-end space-x-2 mb-4">
        <Button 
          variant="outline" 
          onClick={saveReport}
        >
          <Save className="mr-2 h-4 w-4" />
          Salvar
        </Button>
        <Button 
          onClick={downloadPDF}
          disabled={isGenerating}
        >
          {isGenerating ? (
            <span className="flex items-center">
              <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
              Gerando...
            </span>
          ) : (
            <>
              <Download className="mr-2 h-4 w-4" />
              Download PDF
            </>
          )}
        </Button>
      </div>
      
      <Card className="mb-8">
        <CardContent className="p-6 sm:p-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 border-b border-gray-200 pb-8">
            <div className="flex-1 min-w-0">
              <h2 className="font-heading text-2xl font-bold text-gray-900 sm:text-3xl">
                Análise Competitiva: {businessName}
              </h2>
              <p className="mt-1 text-sm text-gray-500">
                Gerado em {new Date(createdAt).toLocaleDateString('pt-BR')} | Localização: {location}
              </p>
            </div>
            <div className="mt-4 md:mt-0 flex-shrink-0">
              <h3 className="text-xl font-bold text-primary-600">Chamad Mappe.ia</h3>
            </div>
          </div>
          
          {/* Executive Summary */}
          <div className="mb-8">
            <h3 className="font-heading text-lg font-medium text-gray-900 mb-3">Resumo Executivo</h3>
            <p className="text-gray-700">{content.executiveSummary}</p>
          </div>
          
          {/* Competitive Landscape */}
          <div className="mb-8">
            <h3 className="font-heading text-lg font-medium text-gray-900 mb-4">Panorama Competitivo</h3>
            
            {/* Graph: Ticket Prices */}
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <h4 className="font-medium text-gray-800 mb-2 text-sm">Faixa de Preços (Ticket Médio)</h4>
              <div className="h-10 bg-gray-200 rounded-full overflow-hidden">
                <div className="flex h-full items-center">
                  <div className="h-full bg-green-400 text-xs flex items-center justify-center text-white px-2" style={{ width: '30%' }}>
                    {content.competitiveInsights.priceRange.currency} {content.competitiveInsights.priceRange.low}
                  </div>
                  <div className="h-full bg-primary-400 text-xs flex items-center justify-center text-white px-2" style={{ width: '30%' }}>
                    {content.competitiveInsights.priceRange.currency} {Math.floor((content.competitiveInsights.priceRange.low + content.competitiveInsights.priceRange.high) / 2)}
                  </div>
                  <div className="h-full bg-accent-400 text-xs flex items-center justify-center text-white px-2" style={{ width: '40%' }}>
                    {content.competitiveInsights.priceRange.currency} {content.competitiveInsights.priceRange.high}+
                  </div>
                </div>
              </div>
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                {content.competitiveInsights.ratings.slice(0, 3).map((rating, index) => (
                  <span key={index}>{rating.competitor}</span>
                ))}
              </div>
            </div>
            
            {/* Graph: Customer Ratings */}
            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <h4 className="font-medium text-gray-800 mb-2 text-sm">Avaliações dos Clientes</h4>
              <div className="space-y-2">
                {content.competitiveInsights.ratings.map((rating, index) => (
                  <div key={index}>
                    <div className="flex items-center">
                      <span className="text-sm w-24">{rating.competitor}</span>
                      <div className="flex-1 h-5 bg-gray-200 rounded-full overflow-hidden">
                        <div className="h-5 bg-green-500 rounded-full" style={{ width: `${(rating.rating / 5) * 100}%` }}></div>
                      </div>
                      <span className="ml-2 text-sm font-medium">{rating.rating}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Channels */}
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-800 mb-2 text-sm">Canais de Venda Utilizados</h4>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                {content.competitiveInsights.channelsUsage.map((channel, index) => (
                  <div key={index} className="text-center">
                    <div className="inline-flex items-center justify-center h-12 w-12 rounded-full bg-primary-100 text-primary-600 mb-2">
                      <i className={`fas ${
                        channel.channel.includes("Física") ? "fa-store" :
                        channel.channel.includes("E-commerce") ? "fa-shopping-cart" :
                        channel.channel.includes("Marketplace") ? "fa-shopping-bag" :
                        "fa-hashtag"
                      }`}></i>
                    </div>
                    <p className="text-xs">{channel.channel}</p>
                    <p className="font-medium text-lg">{channel.percentage}%</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Key Differentiators */}
          <div className="mb-8">
            <h3 className="font-heading text-lg font-medium text-gray-900 mb-3">Principais Diferenciais</h3>
            <div className="overflow-hidden bg-gray-50 rounded-lg border border-gray-200">
              <div className="px-4 py-5 sm:px-6 bg-gray-50">
                <h4 className="text-sm font-medium text-gray-500">Pontos fortes dos concorrentes</h4>
              </div>
              <div className="border-t border-gray-200">
                <dl>
                  {content.keyDifferentiators.map((diff, index) => (
                    <div key={index} className={`${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'} px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6`}>
                      <dt className="text-sm font-medium text-gray-500">{diff.competitor}</dt>
                      <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                        <ul className="list-disc pl-5 space-y-1">
                          {diff.strengths.map((strength, i) => (
                            <li key={i}>{strength}</li>
                          ))}
                        </ul>
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>
            </div>
          </div>
          
          {/* Recommendations */}
          <div>
            <h3 className="font-heading text-lg font-medium text-gray-900 mb-3">Recomendações Estratégicas</h3>
            <div className="bg-primary-50 rounded-lg p-6 border border-primary-100">
              <ul className="space-y-3">
                {content.recommendations.map((rec, index) => (
                  <li key={index} className="flex items-start">
                    <div className="flex-shrink-0">
                      <Check className="h-5 w-5 text-primary-600 mt-0.5" />
                    </div>
                    <p className="ml-3 text-gray-700">{rec}</p>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
