import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";

interface MapLocation {
  lat: number;
  lng: number;
}

interface MapMarker {
  id: number;
  name: string;
  position: MapLocation;
  isMainBusiness?: boolean;
}

interface GoogleMapProps {
  center: MapLocation;
  markers: MapMarker[];
  zoom?: number;
  height?: string;
  onMarkerClick?: (markerId: number) => void;
}

export function GoogleMap({ 
  center, 
  markers, 
  zoom = 13, 
  height = "450px",
  onMarkerClick
}: GoogleMapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [mapMarkers, setMapMarkers] = useState<google.maps.Marker[]>([]);

  // Initialize the map
  useEffect(() => {
    if (mapRef.current && !map) {
      const mapInstance = new google.maps.Map(mapRef.current, {
        center,
        zoom,
        mapTypeControl: false,
        fullscreenControl: false,
        streetViewControl: false,
        zoomControlOptions: {
          position: google.maps.ControlPosition.RIGHT_TOP,
        }
      });
      setMap(mapInstance);
    }
  }, [mapRef, map, center, zoom]);

  // Update markers when they change
  useEffect(() => {
    if (map) {
      // Clear any existing markers
      mapMarkers.forEach(marker => marker.setMap(null));
      
      // Create new markers
      const newMarkers = markers.map(marker => {
        const mapMarker = new google.maps.Marker({
          position: marker.position,
          map,
          title: marker.name,
          icon: marker.isMainBusiness 
            ? {
                path: google.maps.SymbolPath.CIRCLE,
                fillColor: '#6366f1',
                fillOpacity: 1,
                strokeColor: '#ffffff',
                strokeWeight: 2,
                scale: 8,
              }
            : {
                path: google.maps.SymbolPath.CIRCLE,
                fillColor: '#f97316',
                fillOpacity: 1,
                strokeColor: '#ffffff',
                strokeWeight: 2,
                scale: 8,
              },
        });
        
        if (onMarkerClick) {
          mapMarker.addListener('click', () => {
            onMarkerClick(marker.id);
          });
        }
        
        return mapMarker;
      });
      
      setMapMarkers(newMarkers);
      
      // Adjust map bounds to fit all markers
      if (markers.length > 0) {
        const bounds = new google.maps.LatLngBounds();
        markers.forEach(marker => {
          bounds.extend(marker.position);
        });
        map.fitBounds(bounds);
        
        // Don't zoom in too far
        const listener = google.maps.event.addListener(map, 'idle', () => {
          if (map.getZoom() && map.getZoom() > 16) {
            map.setZoom(16);
          }
          google.maps.event.removeListener(listener);
        });
      }
    }
  }, [map, markers, onMarkerClick]);

  return (
    <Card className="overflow-hidden">
      <div className="relative">
        <div 
          ref={mapRef} 
          style={{ height }}
          className="w-full bg-primary-100"
        />
        
        {/* Map Controls */}
        <div className="absolute top-4 right-4 bg-white rounded-md shadow-sm">
          <button 
            className="p-2 text-gray-500 hover:text-primary-600"
            onClick={() => map?.setZoom((map?.getZoom() || 0) + 1)}
          >
            <i className="fas fa-plus"></i>
          </button>
          <button 
            className="p-2 text-gray-500 hover:text-primary-600 border-t border-gray-200"
            onClick={() => map?.setZoom((map?.getZoom() || 0) - 1)}
          >
            <i className="fas fa-minus"></i>
          </button>
        </div>
        
        {/* Map Markers Legend */}
        <div className="absolute bottom-4 left-4 bg-white rounded-md shadow-sm p-3">
          <div className="flex items-center mb-2">
            <div className="h-4 w-4 rounded-full bg-primary-600 mr-2"></div>
            <span className="text-xs text-gray-700">Sua Empresa</span>
          </div>
          <div className="flex items-center">
            <div className="h-4 w-4 rounded-full bg-accent-500 mr-2"></div>
            <span className="text-xs text-gray-700">Concorrentes</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
