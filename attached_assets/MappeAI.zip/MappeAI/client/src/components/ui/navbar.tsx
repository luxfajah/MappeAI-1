import { Link, useLocation } from "wouter";
import { useTheme } from "@/hooks/use-theme";
import { Button } from "@/components/ui/button";
import { Sun, Moon, Map, Search, FileText, User, Home } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";

export function Navbar() {
  const { theme, setTheme } = useTheme();
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();

  // Alternar entre modo claro e escuro
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-card/80 backdrop-blur supports-[backdrop-filter]:bg-card/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center gap-2">
            <Map className="h-6 w-6 text-primary" />
            <span className="logo-text-gradient text-xl md:text-2xl">Mappe.ia</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-1">
            <Link 
              href="/" 
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors hover:bg-accent ${location === "/" ? "text-primary" : "text-muted-foreground"}`}
            >
              <span className="flex items-center gap-2">
                <Home className="h-4 w-4" />
                Início
              </span>
            </Link>
            <Link 
              href="/search/new" 
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors hover:bg-accent ${location.includes("/search") ? "text-primary" : "text-muted-foreground"}`}
            >
              <span className="flex items-center gap-2">
                <Search className="h-4 w-4" />
                Pesquisar
              </span>
            </Link>
            <Link 
              href="/dashboard" 
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors hover:bg-accent ${location === "/dashboard" ? "text-primary" : "text-muted-foreground"}`}
            >
              <span className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Relatórios
              </span>
            </Link>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            aria-label="Alternar tema"
            className="rounded-full"
          >
            {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>
          
          {user ? (
            <div className="flex items-center gap-2">
              <Button variant="ghost" className="text-sm">
                <User className="h-4 w-4 mr-2" />
                {user.username}
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => logoutMutation.mutate()}
              >
                Sair
              </Button>
            </div>
          ) : (
            <Link href="/auth" className="block">
              <Button variant="default" size="sm">
                Entrar
              </Button>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}