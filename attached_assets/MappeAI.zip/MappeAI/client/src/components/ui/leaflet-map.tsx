import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Competitor } from '@/lib/api';

// Fix Leaflet default icon issue
// @ts-ignore - _getIconUrl existe no protótipo mas não está declarado nos tipos
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

// Create custom marker for main business
const mainIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

// Create custom marker for competitors
const competitorIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/0.7.7/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

interface MapLocation {
  lat: number;
  lng: number;
}

interface LeafletMapProps {
  center: MapLocation;
  businessName?: string;
  competitors: Competitor[];
  zoom?: number;
  height?: string;
  onMarkerClick?: (competitor: Competitor) => void;
}

// Component to update the map view when center prop changes
function ChangeMapView({ center }: { center: MapLocation }) {
  const map = useMap();
  
  useEffect(() => {
    map.setView([center.lat, center.lng]);
  }, [map, center]);
  
  return null;
}

export function LeafletMap({
  center,
  businessName,
  competitors,
  zoom = 13,
  height = '400px',
  onMarkerClick
}: LeafletMapProps) {
  return (
    <div style={{ height: height, width: '100%' }}>
      <MapContainer 
        center={[center.lat, center.lng]} 
        zoom={zoom} 
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        <ChangeMapView center={center} />
        
        {/* Main business marker */}
        {businessName && (
          <Marker 
            position={[center.lat, center.lng]} 
            icon={mainIcon}
          >
            <Popup>
              <div>
                <strong>{businessName}</strong>
                <div>Seu negócio</div>
              </div>
            </Popup>
          </Marker>
        )}
        
        {/* Competitor markers */}
        {competitors.map((competitor, index) => {
          if (!competitor.coordinates) return null;
          
          // Add a small offset to each competitor to avoid overlapping markers
          const position = {
            lat: competitor.coordinates.lat + (Math.random() * 0.01 - 0.005),
            lng: competitor.coordinates.lng + (Math.random() * 0.01 - 0.005)
          };
          
          return (
            <Marker 
              key={index} 
              position={[position.lat, position.lng]} 
              icon={competitorIcon}
              eventHandlers={{
                click: () => {
                  if (onMarkerClick) onMarkerClick(competitor);
                }
              }}
            >
              <Popup>
                <div>
                  <strong>{competitor.name}</strong>
                  <div>Distância: {competitor.distance}</div>
                  <div>Avaliação: {competitor.rating} ⭐</div>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}