// Estrutura de dados hierárquica para países, estados e cidades

export interface City {
  id: string;
  name: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  population?: number;
}

export interface State {
  id: string;
  name: string;
  cities: City[];
}

export interface Country {
  id: string;
  name: string;
  states: State[];
}

export const countries: Country[] = [
  {
    id: "br",
    name: "Brasil",
    states: [
      {
        id: "sp",
        name: "São Paulo",
        cities: [
          {
            id: "sp-capital",
            name: "São Paulo",
            coordinates: {
              lat: -23.5505,
              lng: -46.6333
            },
            population: 12325232
          },
          {
            id: "campinas",
            name: "Campinas",
            coordinates: {
              lat: -22.9056,
              lng: -47.0608
            },
            population: 1214000
          },
          {
            id: "santos",
            name: "Santos",
            coordinates: {
              lat: -23.9619,
              lng: -46.3342
            },
            population: 433966
          },
          {
            id: "sjc",
            name: "São José dos Campos",
            coordinates: {
              lat: -23.1791,
              lng: -45.8872
            },
            population: 729737
          },
          {
            id: "ribeirao",
            name: "Ribeirão Preto",
            coordinates: {
              lat: -21.1704,
              lng: -47.8103
            },
            population: 711000
          }
        ]
      },
      {
        id: "rj",
        name: "Rio de Janeiro",
        cities: [
          {
            id: "rj-capital",
            name: "Rio de Janeiro",
            coordinates: {
              lat: -22.9068,
              lng: -43.1729
            },
            population: 6747815
          },
          {
            id: "niteroi",
            name: "Niterói",
            coordinates: {
              lat: -22.8858,
              lng: -43.1152
            },
            population: 513584
          },
          {
            id: "petropolis",
            name: "Petrópolis",
            coordinates: {
              lat: -22.5049,
              lng: -43.1789
            },
            population: 306678
          }
        ]
      },
      {
        id: "mg",
        name: "Minas Gerais",
        cities: [
          {
            id: "bh",
            name: "Belo Horizonte",
            coordinates: {
              lat: -19.9167,
              lng: -43.9345
            },
            population: 2722000
          },
          {
            id: "uberlandia",
            name: "Uberlândia",
            coordinates: {
              lat: -18.9186,
              lng: -48.2772
            },
            population: 699097
          },
          {
            id: "jf",
            name: "Juiz de Fora",
            coordinates: {
              lat: -21.7639,
              lng: -43.3505
            },
            population: 573285
          }
        ]
      },
      {
        id: "rs",
        name: "Rio Grande do Sul",
        cities: [
          {
            id: "poa",
            name: "Porto Alegre",
            coordinates: {
              lat: -30.0346,
              lng: -51.2177
            },
            population: 1488252
          },
          {
            id: "caxias",
            name: "Caxias do Sul",
            coordinates: {
              lat: -29.1634,
              lng: -51.1796
            },
            population: 517451
          },
          {
            id: "pelotas",
            name: "Pelotas",
            coordinates: {
              lat: -31.7651,
              lng: -52.3371
            },
            population: 343132
          }
        ]
      },
      {
        id: "ba",
        name: "Bahia",
        cities: [
          {
            id: "salvador",
            name: "Salvador",
            coordinates: {
              lat: -12.9714,
              lng: -38.5014
            },
            population: 2886698
          },
          {
            id: "feira",
            name: "Feira de Santana",
            coordinates: {
              lat: -12.2667,
              lng: -38.9667
            },
            population: 619609
          },
          {
            id: "vitoria",
            name: "Vitória da Conquista",
            coordinates: {
              lat: -14.8572,
              lng: -40.8392
            },
            population: 341128
          }
        ]
      },
      {
        id: "pr",
        name: "Paraná",
        cities: [
          {
            id: "curitiba",
            name: "Curitiba",
            coordinates: {
              lat: -25.4297,
              lng: -49.2719
            },
            population: 1948626
          },
          {
            id: "londrina",
            name: "Londrina",
            coordinates: {
              lat: -23.3103,
              lng: -51.1628
            },
            population: 575377
          },
          {
            id: "maringa",
            name: "Maringá",
            coordinates: {
              lat: -23.4253,
              lng: -51.9386
            },
            population: 430157
          }
        ]
      }
    ]
  },
  {
    id: "ar",
    name: "Argentina",
    states: [
      {
        id: "ba",
        name: "Buenos Aires",
        cities: [
          {
            id: "ba-capital",
            name: "Buenos Aires",
            coordinates: {
              lat: -34.6037,
              lng: -58.3816
            },
            population: 3075646
          },
          {
            id: "laplata",
            name: "La Plata",
            coordinates: {
              lat: -34.9205,
              lng: -57.9536
            },
            population: 899523
          }
        ]
      },
      {
        id: "cor",
        name: "Córdoba",
        cities: [
          {
            id: "cordoba",
            name: "Córdoba",
            coordinates: {
              lat: -31.4201,
              lng: -64.1888
            },
            population: 1454536
          }
        ]
      }
    ]
  }
];

// Funções úteis para obter dados
export function getCountryById(id: string): Country | undefined {
  return countries.find(country => country.id === id);
}

export function getStatesByCountryId(countryId: string): State[] {
  const country = getCountryById(countryId);
  return country ? country.states : [];
}

export function getStateById(countryId: string, stateId: string): State | undefined {
  const states = getStatesByCountryId(countryId);
  return states.find(state => state.id === stateId);
}

export function getCitiesByStateId(countryId: string, stateId: string): City[] {
  const state = getStateById(countryId, stateId);
  return state ? state.cities : [];
}

export function getCityById(countryId: string, stateId: string, cityId: string): City | undefined {
  const cities = getCitiesByStateId(countryId, stateId);
  return cities.find(city => city.id === cityId);
}

export function formatLocation(countryId: string, stateId: string, cityId: string): string {
  const country = getCountryById(countryId);
  const state = getStateById(countryId, stateId);
  const city = getCityById(countryId, stateId, cityId);
  
  if (country && state && city) {
    return `${city.name}, ${state.name}, ${country.name}`;
  }
  
  return "";
}

export function getCoordinates(countryId: string, stateId: string, cityId: string): {lat: number, lng: number} | null {
  const city = getCityById(countryId, stateId, cityId);
  return city ? city.coordinates : null;
}