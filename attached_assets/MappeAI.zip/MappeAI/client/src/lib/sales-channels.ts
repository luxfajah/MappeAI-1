// Lista abrangente de canais de venda

export interface SalesChannel {
  id: string;
  name: string;
  description: string;
}

export const salesChannels: SalesChannel[] = [
  {
    id: "physical_store",
    name: "Loja Física",
    description: "Estabelecimento físico onde os clientes podem visitar, ver e comprar produtos ou serviços pessoalmente."
  },
  {
    id: "own_ecommerce",
    name: "E-commerce Próprio",
    description: "Site ou plataforma digital própria onde os clientes podem comprar produtos ou serviços diretamente."
  },
  {
    id: "marketplace",
    name: "Marketplace",
    description: "Plataformas de terceiros onde você vende seus produtos junto com outros vendedores (Mercado Livre, Amazon, etc)."
  },
  {
    id: "social_media",
    name: "Redes Sociais",
    description: "Venda direta através de redes sociais como Instagram, Facebook, TikTok e WhatsApp."
  },
  {
    id: "delivery_own",
    name: "Delivery Próprio",
    description: "Serviço de entrega gerenciado pelo próprio negócio, usando frota ou entregadores próprios."
  },
  {
    id: "delivery_apps",
    name: "Apps de Delivery",
    description: "Parceria com aplicativos de delivery como iFood, Rappi, Uber Eats, etc."
  },
  {
    id: "whatsapp",
    name: "WhatsApp Business",
    description: "Atendimento e vendas diretamente pelo WhatsApp ou WhatsApp Business."
  },
  {
    id: "phone",
    name: "Tele-Vendas",
    description: "Atendimento e vendas por telefone ou call center."
  },
  {
    id: "catalog",
    name: "Catálogo Físico",
    description: "Vendas através de catálogos físicos, comum em vendas porta-a-porta ou por consultores."
  },
  {
    id: "resellers",
    name: "Revendedores",
    description: "Rede de revendedores ou consultores que comercializam seus produtos."
  },
  {
    id: "wholesale",
    name: "Atacado",
    description: "Venda em grandes quantidades para outros negócios revenderem."
  },
  {
    id: "franchises",
    name: "Franquias",
    description: "Expansão através de unidades franqueadas que vendem seus produtos/serviços."
  },
  {
    id: "popup_store",
    name: "Pop-up Store",
    description: "Lojas temporárias em eventos, feiras ou locais estratégicos."
  },
  {
    id: "subscription",
    name: "Assinatura/Recorrência",
    description: "Modelo de negócio baseado em assinaturas mensais ou periódicas."
  },
  {
    id: "b2b",
    name: "B2B (Business-to-Business)",
    description: "Vendas corporativas para outras empresas, governo ou instituições."
  },
  {
    id: "affiliate",
    name: "Marketing de Afiliados",
    description: "Parceiros que divulgam seus produtos em troca de comissão."
  },
  {
    id: "vending_machine",
    name: "Máquinas de Venda Automática",
    description: "Vending machines em locais estratégicos."
  },
  {
    id: "live_shopping",
    name: "Live Shopping",
    description: "Vendas realizadas durante transmissões ao vivo em plataformas como Instagram, YouTube ou TikTok."
  },
  {
    id: "dark_kitchen",
    name: "Dark Kitchen",
    description: "Cozinha exclusiva para delivery, sem atendimento presencial (para negócios de alimentação)."
  },
  {
    id: "click_collect",
    name: "Clique e Retire",
    description: "Cliente compra online e retira na loja física ou em um ponto de coleta."
  }
];

// Função para obter um canal de venda pelo ID
export function getSalesChannelById(id: string): SalesChannel | undefined {
  return salesChannels.find(channel => channel.id === id);
}

// Função para formatar vários canais selecionados
export function formatSalesChannels(channelIds: string[]): string[] {
  return channelIds.map(id => {
    const channel = getSalesChannelById(id);
    return channel ? channel.name : id;
  });
}