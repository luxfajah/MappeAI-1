export interface CidadeBrasileira {
  nome: string;
  estado: string;
  coordenadas: {
    lat: number;
    lng: number;
  };
  populacao?: number;
}

// Lista das principais cidades brasileiras com suas coordenadas
export const cidadesBrasileiras: CidadeBrasileira[] = [
  {
    nome: "São Paulo",
    estado: "SP",
    coordenadas: { lat: -23.5505, lng: -46.6333 },
    populacao: 12325232
  },
  {
    nome: "Rio de Janeiro",
    estado: "RJ",
    coordenadas: { lat: -22.9068, lng: -43.1729 },
    populacao: 6747815
  },
  {
    nome: "Brasília",
    estado: "DF",
    coordenadas: { lat: -15.7801, lng: -47.9292 },
    populacao: 3055149
  },
  {
    nome: "Salvador",
    estado: "BA",
    coordenadas: { lat: -12.9716, lng: -38.5016 },
    populacao: 2886698
  },
  {
    nome: "Fortaleza",
    estado: "CE",
    coordenadas: { lat: -3.7319, lng: -38.5267 },
    populacao: 2686612
  },
  {
    nome: "Belo Horizonte",
    estado: "MG",
    coordenadas: { lat: -19.9167, lng: -43.9345 },
    populacao: 2521564
  },
  {
    nome: "Manaus",
    estado: "AM",
    coordenadas: { lat: -3.1019, lng: -60.0250 },
    populacao: 2219580
  },
  {
    nome: "Curitiba",
    estado: "PR",
    coordenadas: { lat: -25.4297, lng: -49.2719 },
    populacao: 1948626
  },
  {
    nome: "Recife",
    estado: "PE",
    coordenadas: { lat: -8.0476, lng: -34.8770 },
    populacao: 1653461
  },
  {
    nome: "Porto Alegre",
    estado: "RS",
    coordenadas: { lat: -30.0328, lng: -51.2302 },
    populacao: 1488252
  },
  {
    nome: "Belém",
    estado: "PA",
    coordenadas: { lat: -1.4558, lng: -48.4902 },
    populacao: 1499641
  },
  {
    nome: "Goiânia",
    estado: "GO",
    coordenadas: { lat: -16.6799, lng: -49.2550 },
    populacao: 1536097
  },
  {
    nome: "Guarulhos",
    estado: "SP",
    coordenadas: { lat: -23.4538, lng: -46.5333 },
    populacao: 1392121
  },
  {
    nome: "Campinas",
    estado: "SP",
    coordenadas: { lat: -22.9056, lng: -47.0608 },
    populacao: 1213792
  },
  {
    nome: "São Luís",
    estado: "MA",
    coordenadas: { lat: -2.5297, lng: -44.3022 },
    populacao: 1108975
  },
  {
    nome: "São Gonçalo",
    estado: "RJ",
    coordenadas: { lat: -22.8267, lng: -43.0631 },
    populacao: 1091737
  },
  {
    nome: "Maceió",
    estado: "AL",
    coordenadas: { lat: -9.6498, lng: -35.7089 },
    populacao: 1025360
  },
  {
    nome: "Natal",
    estado: "RN",
    coordenadas: { lat: -5.7945, lng: -35.2120 },
    populacao: 896708
  },
  {
    nome: "João Pessoa",
    estado: "PB",
    coordenadas: { lat: -7.1195, lng: -34.8450 },
    populacao: 817511
  },
  {
    nome: "Florianópolis",
    estado: "SC",
    coordenadas: { lat: -27.5969, lng: -48.5495 },
    populacao: 508826
  },
  {
    nome: "Niterói",
    estado: "RJ",
    coordenadas: { lat: -22.8902, lng: -43.1152 },
    populacao: 515317
  },
  {
    nome: "Santos",
    estado: "SP",
    coordenadas: { lat: -23.9608, lng: -46.3259 },
    populacao: 433656
  },
  {
    nome: "Vitória",
    estado: "ES",
    coordenadas: { lat: -20.2976, lng: -40.2958 },
    populacao: 365855
  },
  {
    nome: "Uberlândia",
    estado: "MG",
    coordenadas: { lat: -18.9186, lng: -48.2772 },
    populacao: 699097
  },
  {
    nome: "Ribeirão Preto",
    estado: "SP",
    coordenadas: { lat: -21.1775, lng: -47.8103 },
    populacao: 711825
  },
  {
    nome: "Londrina",
    estado: "PR",
    coordenadas: { lat: -23.3100, lng: -51.1628 },
    populacao: 575377
  },
  {
    nome: "Joinville",
    estado: "SC",
    coordenadas: { lat: -26.3044, lng: -48.8489 },
    populacao: 597658
  },
  {
    nome: "Maringá",
    estado: "PR",
    coordenadas: { lat: -23.4257, lng: -51.9404 },
    populacao: 430157
  },
  {
    nome: "Juiz de Fora",
    estado: "MG",
    coordenadas: { lat: -21.7642, lng: -43.3502 },
    populacao: 573285
  },
  {
    nome: "Campo Grande",
    estado: "MS",
    coordenadas: { lat: -20.4697, lng: -54.6201 },
    populacao: 906092
  },
  {
    nome: "Teresina",
    estado: "PI",
    coordenadas: { lat: -5.0919, lng: -42.8034 },
    populacao: 871126
  },
  {
    nome: "Aracaju",
    estado: "SE",
    coordenadas: { lat: -10.9472, lng: -37.0731 },
    populacao: 664908
  },
  {
    nome: "Cuiabá",
    estado: "MT",
    coordenadas: { lat: -15.6014, lng: -56.0979 },
    populacao: 618124
  },
  {
    nome: "Porto Velho",
    estado: "RO",
    coordenadas: { lat: -8.7608, lng: -63.9025 },
    populacao: 494013
  },
  {
    nome: "Boa Vista",
    estado: "RR",
    coordenadas: { lat: 2.8202, lng: -60.6759 },
    populacao: 399213
  },
  {
    nome: "Macapá",
    estado: "AP",
    coordenadas: { lat: 0.0389, lng: -51.0664 },
    populacao: 503327
  },
  {
    nome: "Palmas",
    estado: "TO",
    coordenadas: { lat: -10.2491, lng: -48.3243 },
    populacao: 313349
  },
  {
    nome: "Rio Branco",
    estado: "AC",
    coordenadas: { lat: -9.9753, lng: -67.8249 },
    populacao: 413418
  }
];

// Função auxiliar para formatar a exibição da cidade no dropdown
export const formatarCidade = (cidade: CidadeBrasileira): string => {
  return `${cidade.nome} - ${cidade.estado}`;
};

// Função para encontrar uma cidade pelo nome
export const encontrarCidadePeloNome = (nome: string): CidadeBrasileira | undefined => {
  return cidadesBrasileiras.find(cidade => formatarCidade(cidade) === nome);
};

// Função para obter coordenadas de uma cidade
export const obterCoordenadas = (cidade: string): { lat: number, lng: number } => {
  const cidadeEncontrada = encontrarCidadePeloNome(cidade);
  
  if (cidadeEncontrada) {
    return cidadeEncontrada.coordenadas;
  }
  
  // Coordenadas padrão (São Paulo) se não encontrar a cidade
  return { lat: -23.5505, lng: -46.6333 };
};