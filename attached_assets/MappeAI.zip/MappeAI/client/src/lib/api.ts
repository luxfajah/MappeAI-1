import { apiRequest } from "./queryClient";
import { Search, InsertSearch } from "@shared/schema";

export interface Competitor {
  id: number;
  searchId: number;
  name: string;
  distance: string;
  rating: string;
  reviewCount?: number;
  ticketPrice: string;
  operationTime: string;
  salesChannels: string[];
  location: string;
  placeId?: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
  links?: {
    website?: string;
    social?: string[];
  };
  differentiators?: string[];
}

export interface SearchResult {
  search: Search;
  competitors: Competitor[];
}

export interface Report {
  id: number;
  searchId: number;
  userId: number;
  title: string;
  summary: string;
  content: ReportContent;
  selectedCompetitors: number[];
  createdAt: Date;
}

export interface ReportContent {
  executiveSummary: string;
  competitiveInsights: {
    priceRange: {
      low: number;
      high: number;
      currency: string;
    };
    ratings: {
      competitor: string;
      rating: number;
    }[];
    channelsUsage: {
      channel: string;
      percentage: number;
    }[];
  };
  keyDifferentiators: {
    competitor: string;
    strengths: string[];
  }[];
  recommendations: string[];
}

export interface ReportResponse {
  report: Report;
  content: ReportContent;
}

export interface PlanStatus {
  planType: string;
  searchesUsed: number;
  limit: number;
  remaining: number;
}

// Search functions
export async function createSearch(data: InsertSearch): Promise<SearchResult> {
  const response = await apiRequest("POST", "/api/search", data);
  return response.json();
}

export async function getSearch(id: number): Promise<SearchResult> {
  const response = await apiRequest("GET", `/api/search/${id}`);
  return response.json();
}

export async function getUserSearches(): Promise<Search[]> {
  const response = await apiRequest("GET", "/api/searches");
  return response.json();
}

// Report functions
export async function createReport(searchId: number, selectedCompetitors: number[]): Promise<ReportResponse> {
  const response = await apiRequest("POST", "/api/report", { searchId, selectedCompetitors });
  return response.json();
}

export async function getReport(id: number): Promise<Report> {
  const response = await apiRequest("GET", `/api/report/${id}`);
  return response.json();
}

export async function getUserReports(): Promise<Report[]> {
  const response = await apiRequest("GET", "/api/reports");
  return response.json();
}

// Plan functions
export async function getPlanStatus(): Promise<PlanStatus> {
  const response = await apiRequest("GET", "/api/plan");
  return response.json();
}
