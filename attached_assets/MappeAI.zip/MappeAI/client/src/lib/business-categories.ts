// Lista abrangente de categorias e subcategorias de negócios

export interface BusinessSubcategory {
  id: string;
  name: string;
}

export interface BusinessCategory {
  id: string;
  name: string;
  subcategories: BusinessSubcategory[];
}

export const businessCategories: BusinessCategory[] = [
  {
    id: "retail",
    name: "Varejo",
    subcategories: [
      { id: "supermarket", name: "Supermercado" },
      { id: "hypermarket", name: "Hipermercado" },
      { id: "convenience", name: "Loja de Conveniência" },
      { id: "department_store", name: "Loja de Departamento" },
      { id: "clothing", name: "Vestuário e Moda" },
      { id: "footwear", name: "Calçados" },
      { id: "jewelry", name: "Joalheria e Acessórios" },
      { id: "sporting_goods", name: "Artigos Esportivos" },
      { id: "electronics", name: "Eletrônicos e Eletrodomésticos" },
      { id: "furniture", name: "Móveis e Decoração" },
      { id: "hardware", name: "Material de Construção" },
      { id: "bookstore", name: "Livraria e Papelaria" },
      { id: "pet_shop", name: "Pet Shop" },
      { id: "toys", name: "Brinquedos e Jogos" },
      { id: "cosmetics", name: "Cosméticos e Perfumaria" }
    ]
  },
  {
    id: "food_beverage",
    name: "Alimentação e Bebidas",
    subcategories: [
      { id: "restaurant", name: "Restaurante" },
      { id: "fast_food", name: "Fast Food" },
      { id: "cafe", name: "Café e Padaria" },
      { id: "bar", name: "Bar e Pub" },
      { id: "ice_cream", name: "Sorveteria" },
      { id: "pizzaria", name: "Pizzaria" },
      { id: "food_truck", name: "Food Truck" },
      { id: "buffet", name: "Buffet" },
      { id: "bakery", name: "Confeitaria" },
      { id: "delivery_only", name: "Delivery (sem loja física)" }
    ]
  },
  {
    id: "health",
    name: "Saúde",
    subcategories: [
      { id: "pharmacy", name: "Farmácia e Drogaria" },
      { id: "hospital", name: "Hospital" },
      { id: "clinic", name: "Clínica Médica" },
      { id: "dental", name: "Consultório Odontológico" },
      { id: "physiotherapy", name: "Fisioterapia" },
      { id: "laboratory", name: "Laboratório de Análises" },
      { id: "mental_health", name: "Saúde Mental" },
      { id: "gym", name: "Academia" },
      { id: "natural_health", name: "Produtos Naturais" },
      { id: "telemedicine", name: "Telemedicina" }
    ]
  },
  {
    id: "services",
    name: "Serviços",
    subcategories: [
      { id: "hair_beauty", name: "Salão de Beleza e Barbearia" },
      { id: "laundry", name: "Lavanderia" },
      { id: "repair", name: "Consertos e Reparos" },
      { id: "car_wash", name: "Lava-Rápido" },
      { id: "tailor", name: "Alfaiataria" },
      { id: "printing", name: "Gráfica e Impressão" },
      { id: "locksmith", name: "Chaveiro" },
      { id: "cleaning", name: "Serviços de Limpeza" },
      { id: "photography", name: "Fotografia" },
      { id: "event_planning", name: "Organização de Eventos" }
    ]
  },
  {
    id: "automotive",
    name: "Automotivo",
    subcategories: [
      { id: "dealership", name: "Concessionária" },
      { id: "auto_parts", name: "Autopeças" },
      { id: "mechanic", name: "Oficina Mecânica" },
      { id: "tire_shop", name: "Loja de Pneus" },
      { id: "gas_station", name: "Posto de Combustível" },
      { id: "car_rental", name: "Aluguel de Veículos" },
      { id: "auto_body", name: "Funilaria e Pintura" },
      { id: "auto_glass", name: "Vidraçaria Automotiva" },
      { id: "motorcycle", name: "Motos e Acessórios" },
      { id: "auto_electrical", name: "Elétrica Automotiva" }
    ]
  },
  {
    id: "education",
    name: "Educação e Treinamento",
    subcategories: [
      { id: "school", name: "Escola" },
      { id: "university", name: "Universidade" },
      { id: "technical_school", name: "Escola Técnica" },
      { id: "language_school", name: "Escola de Idiomas" },
      { id: "tutoring", name: "Reforço Escolar" },
      { id: "driving_school", name: "Auto Escola" },
      { id: "professional_course", name: "Cursos Profissionalizantes" },
      { id: "music_school", name: "Escola de Música" },
      { id: "cooking_school", name: "Escola de Culinária" },
      { id: "online_courses", name: "Cursos Online" }
    ]
  },
  {
    id: "technology",
    name: "Tecnologia",
    subcategories: [
      { id: "software", name: "Desenvolvimento de Software" },
      { id: "web_dev", name: "Desenvolvimento Web" },
      { id: "app_dev", name: "Desenvolvimento de Aplicativos" },
      { id: "it_services", name: "Serviços de TI" },
      { id: "computer_repair", name: "Conserto de Computadores" },
      { id: "data_services", name: "Serviços de Dados" },
      { id: "cybersecurity", name: "Segurança Cibernética" },
      { id: "digital_marketing", name: "Marketing Digital" },
      { id: "cloud_services", name: "Serviços em Nuvem" },
      { id: "telecom", name: "Telecomunicações" }
    ]
  },
  {
    id: "tourism",
    name: "Turismo e Hospedagem",
    subcategories: [
      { id: "hotel", name: "Hotel" },
      { id: "inn", name: "Pousada" },
      { id: "hostel", name: "Hostel" },
      { id: "travel_agency", name: "Agência de Viagens" },
      { id: "tour_guide", name: "Guia Turístico" },
      { id: "tourist_attraction", name: "Atração Turística" },
      { id: "resort", name: "Resort" },
      { id: "camping", name: "Camping" },
      { id: "vacation_rental", name: "Aluguel de Temporada" },
      { id: "ecotourism", name: "Ecoturismo" }
    ]
  },
  {
    id: "entertainment",
    name: "Entretenimento e Lazer",
    subcategories: [
      { id: "cinema", name: "Cinema" },
      { id: "theater", name: "Teatro" },
      { id: "museum", name: "Museu" },
      { id: "nightclub", name: "Casa Noturna" },
      { id: "concert_venue", name: "Casa de Shows" },
      { id: "arcade", name: "Fliperama e Jogos" },
      { id: "park", name: "Parque de Diversões" },
      { id: "sports_venue", name: "Espaço Esportivo" },
      { id: "recreational_center", name: "Centro Recreativo" },
      { id: "escape_room", name: "Escape Room" }
    ]
  },
  {
    id: "real_estate",
    name: "Imobiliário",
    subcategories: [
      { id: "real_estate_agency", name: "Imobiliária" },
      { id: "construction", name: "Construtora" },
      { id: "architecture", name: "Escritório de Arquitetura" },
      { id: "interior_design", name: "Design de Interiores" },
      { id: "property_mgmt", name: "Administração de Imóveis" },
      { id: "property_appraisal", name: "Avaliação de Imóveis" },
      { id: "landscaping", name: "Paisagismo" },
      { id: "engineering", name: "Engenharia" },
      { id: "home_inspection", name: "Inspeção de Imóveis" },
      { id: "rental_management", name: "Gestão de Locações" }
    ]
  },
  {
    id: "finance",
    name: "Finanças e Seguros",
    subcategories: [
      { id: "bank", name: "Banco" },
      { id: "credit_union", name: "Cooperativa de Crédito" },
      { id: "insurance", name: "Seguradora" },
      { id: "accounting", name: "Contabilidade" },
      { id: "financial_advisor", name: "Consultoria Financeira" },
      { id: "investment_firm", name: "Empresa de Investimentos" },
      { id: "tax_service", name: "Serviços Tributários" },
      { id: "credit_repair", name: "Reparação de Crédito" },
      { id: "mortgage_broker", name: "Financiamento Imobiliário" },
      { id: "payroll_services", name: "Serviços de Folha de Pagamento" }
    ]
  },
  {
    id: "professional",
    name: "Serviços Profissionais",
    subcategories: [
      { id: "law_firm", name: "Escritório de Advocacia" },
      { id: "consulting", name: "Consultoria Empresarial" },
      { id: "marketing_agency", name: "Agência de Marketing" },
      { id: "advertising", name: "Publicidade" },
      { id: "design_studio", name: "Estúdio de Design" },
      { id: "translation", name: "Tradução e Interpretação" },
      { id: "recruitment", name: "Recrutamento e Seleção" },
      { id: "public_relations", name: "Relações Públicas" },
      { id: "business_support", name: "Apoio Empresarial" },
      { id: "notary", name: "Cartório e Tabelionato" }
    ]
  },
  {
    id: "transport",
    name: "Transporte e Logística",
    subcategories: [
      { id: "transport_company", name: "Empresa de Transporte" },
      { id: "shipping", name: "Transporte de Cargas" },
      { id: "courier", name: "Serviço de Entregas" },
      { id: "moving_company", name: "Empresa de Mudanças" },
      { id: "taxi_service", name: "Serviço de Táxi" },
      { id: "ride_sharing", name: "Transporte por Aplicativo" },
      { id: "logistics", name: "Logística" },
      { id: "freight_forwarding", name: "Despachante Aduaneiro" },
      { id: "warehousing", name: "Armazenagem" },
      { id: "container_service", name: "Serviço de Contêineres" }
    ]
  },
  {
    id: "manufacturing",
    name: "Indústria e Manufatura",
    subcategories: [
      { id: "textile", name: "Têxtil e Vestuário" },
      { id: "food_production", name: "Produção de Alimentos" },
      { id: "beverage", name: "Bebidas" },
      { id: "furniture_mfg", name: "Móveis" },
      { id: "electronics_mfg", name: "Eletrônicos" },
      { id: "chemical", name: "Químicos" },
      { id: "automotive_mfg", name: "Automotiva" },
      { id: "machinery", name: "Máquinas e Equipamentos" },
      { id: "plastic", name: "Plásticos" },
      { id: "metal", name: "Metalurgia" }
    ]
  },
  {
    id: "agriculture",
    name: "Agricultura e Pecuária",
    subcategories: [
      { id: "farm", name: "Fazenda e Produção Agrícola" },
      { id: "livestock", name: "Criação de Animais" },
      { id: "agricultural_supply", name: "Insumos Agrícolas" },
      { id: "agribusiness", name: "Agroindústria" },
      { id: "organic_farm", name: "Agricultura Orgânica" },
      { id: "horticulture", name: "Horticultura" },
      { id: "agricultural_machinery", name: "Máquinas Agrícolas" },
      { id: "irrigation", name: "Sistemas de Irrigação" },
      { id: "animal_feed", name: "Ração Animal" },
      { id: "veterinary", name: "Serviços Veterinários" }
    ]
  }
];

// Funções úteis para obter categorias e subcategorias
export function getCategoryById(id: string): BusinessCategory | undefined {
  return businessCategories.find(category => category.id === id);
}

export function getSubcategoriesByCategoryId(categoryId: string): BusinessSubcategory[] {
  const category = getCategoryById(categoryId);
  return category ? category.subcategories : [];
}

export function getSubcategoryById(categoryId: string, subcategoryId: string): BusinessSubcategory | undefined {
  const subcategories = getSubcategoriesByCategoryId(categoryId);
  return subcategories.find(subcategory => subcategory.id === subcategoryId);
}

export function formatBusinessType(categoryId: string, subcategoryId: string): string {
  const category = getCategoryById(categoryId);
  const subcategory = getSubcategoryById(categoryId, subcategoryId);
  
  if (category && subcategory) {
    return `${subcategory.name} (${category.name})`;
  }
  
  return "";
}