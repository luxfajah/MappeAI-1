import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { createSearch } from "@/lib/api";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { ArrowLeft, Loader2, MapPin, Search, Building, ShoppingCart, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  SelectGroup,
  SelectLabel,
} from "@/components/ui/select";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger 
} from "@/components/ui/accordion";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";

// Import das novas estruturas de dados
import { 
  countries, 
  getStatesByCountryId,
  getCitiesByStateId,
  formatLocation 
} from "@/lib/locations-data";
import { 
  businessCategories, 
  getSubcategoriesByCategoryId,
  formatBusinessType 
} from "@/lib/business-categories";
import {
  salesChannels
} from "@/lib/sales-channels";

// Schema para o formulário de pesquisa aprimorado
const searchFormSchema = z.object({
  businessName: z.string().min(2, {
    message: "O nome da empresa deve ter pelo menos 2 caracteres.",
  }),
  businessCategory: z.string({
    required_error: "Selecione uma categoria de negócio.",
  }),
  businessSubcategory: z.string({
    required_error: "Selecione uma subcategoria.",
  }),
  country: z.string({
    required_error: "Selecione um país.",
  }),
  state: z.string({
    required_error: "Selecione um estado.",
  }),
  city: z.string({
    required_error: "Selecione uma cidade.",
  }),
  salesChannels: z.array(z.string()).min(1, {
    message: "Selecione pelo menos um canal de venda.",
  }),
  competitiveAdvantages: z.string().optional(),
  targetAudience: z.string().optional(),
  priceRange: z.object({
    min: z.string().optional(),
    max: z.string().optional(),
  }),
  keywords: z.string().optional(),
  businessDescription: z.string().optional(),
});

type SearchFormValues = z.infer<typeof searchFormSchema>;

export default function SearchForm() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Estados para as seleções em cascata
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedState, setSelectedState] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [availableStates, setAvailableStates] = useState<any[]>([]);
  const [availableCities, setAvailableCities] = useState<any[]>([]);
  const [availableSubcategories, setAvailableSubcategories] = useState<any[]>([]);
  
  // Form setup com o esquema aprimorado
  const form = useForm<SearchFormValues>({
    resolver: zodResolver(searchFormSchema),
    defaultValues: {
      businessName: "",
      businessCategory: "",
      businessSubcategory: "",
      country: "",
      state: "",
      city: "",
      salesChannels: [],
      competitiveAdvantages: "",
      targetAudience: "",
      priceRange: {
        min: "",
        max: "",
      },
      keywords: "",
      businessDescription: "",
    },
  });

  // Atualizar estados disponíveis quando o país mudar
  useEffect(() => {
    if (selectedCountry) {
      const states = getStatesByCountryId(selectedCountry);
      setAvailableStates(states);
      setSelectedState("");
      form.setValue("state", "");
      form.setValue("city", "");
    }
  }, [selectedCountry, form]);

  // Atualizar cidades disponíveis quando o estado mudar
  useEffect(() => {
    if (selectedCountry && selectedState) {
      const cities = getCitiesByStateId(selectedCountry, selectedState);
      setAvailableCities(cities);
      form.setValue("city", "");
    }
  }, [selectedState, selectedCountry, form]);

  // Atualizar subcategorias disponíveis quando a categoria mudar
  useEffect(() => {
    if (selectedCategory) {
      const subcategories = getSubcategoriesByCategoryId(selectedCategory);
      setAvailableSubcategories(subcategories);
      form.setValue("businessSubcategory", "");
    }
  }, [selectedCategory, form]);

  // Create search mutation
  const searchMutation = useMutation({
    mutationFn: createSearch,
    onSuccess: (data) => {
      toast({
        title: "Pesquisa criada com sucesso!",
        description: "Redirecionando para os resultados...",
      });
      setLocation(`/search/${data.search.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao criar pesquisa",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  function onSubmit(values: SearchFormValues) {
    // Process keywords to array if provided
    const keywords = values.keywords 
      ? values.keywords.split(',').map(k => k.trim()).filter(k => k.length > 0) 
      : [];
    
    // Formatar o tipo de negócio e a localização
    const businessType = formatBusinessType(values.businessCategory, values.businessSubcategory);
    const location = formatLocation(values.country, values.state, values.city);
    
    // Criar um objeto com vantagens competitivas, público-alvo, etc.
    const additionalInfo = {
      competitiveAdvantages: values.competitiveAdvantages || undefined,
      targetAudience: values.targetAudience || undefined,
      priceRange: (values.priceRange.min || values.priceRange.max) 
        ? {
            min: parseFloat(values.priceRange.min || "0"),
            max: parseFloat(values.priceRange.max || "0"),
            currency: "R$"
          }
        : undefined,
      businessDescription: values.businessDescription || undefined
    };
    
    // Prepare data for API
    const searchData = {
      businessName: values.businessName,
      businessType,
      location,
      salesChannels: values.salesChannels,
      keywords,
      userId: user?.id || 0,
      additionalInfo: JSON.stringify(additionalInfo)
    };
    
    // Submit to API
    searchMutation.mutate(searchData);
  }

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon"
                className="mr-4 hover:text-primary hover:bg-accent" 
                onClick={() => setLocation("/dashboard")}
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <h1 className="font-heading text-2xl font-bold">Nova Pesquisa</h1>
            </div>
            <div className="hidden sm:flex items-center space-x-2">
              <Search className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium text-muted-foreground">Mapeando seu mercado com IA</span>
            </div>
          </div>
        </div>
      </div>

      {/* Form Section */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="form-section rounded-lg border shadow-sm">
          <div className="px-6 py-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <Tabs defaultValue="basic" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 bg-muted/50 p-1 rounded-lg">
                    <TabsTrigger value="basic" className="rounded-md data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                      <Building className="h-4 w-4 mr-2" />
                      Informações Básicas
                    </TabsTrigger>
                    <TabsTrigger value="location" className="rounded-md data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                      <MapPin className="h-4 w-4 mr-2" />
                      Localização
                    </TabsTrigger>
                    <TabsTrigger value="advanced" className="rounded-md data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                      <Info className="h-4 w-4 mr-2" />
                      Detalhes Adicionais
                    </TabsTrigger>
                  </TabsList>
                  
                  {/* Aba de informações básicas */}
                  <TabsContent value="basic" className="space-y-6 pt-4">
                    <FormField
                      control={form.control}
                      name="businessName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome da Empresa/Marca</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: Café do Centro" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                      <FormField
                        control={form.control}
                        name="businessCategory"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Categoria do Negócio</FormLabel>
                            <Select 
                              onValueChange={(value) => {
                                field.onChange(value);
                                setSelectedCategory(value);
                              }}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Selecione uma categoria" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <ScrollArea className="h-80">
                                  {businessCategories.map((category) => (
                                    <SelectItem 
                                      key={category.id} 
                                      value={category.id}
                                    >
                                      {category.name}
                                    </SelectItem>
                                  ))}
                                </ScrollArea>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="businessSubcategory"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tipo Específico</FormLabel>
                            <Select 
                              onValueChange={field.onChange}
                              value={field.value}
                              disabled={!selectedCategory}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder={selectedCategory ? "Selecione um tipo" : "Selecione uma categoria primeiro"} />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <ScrollArea className="h-80">
                                  {availableSubcategories.map((subcategory) => (
                                    <SelectItem 
                                      key={subcategory.id} 
                                      value={subcategory.id}
                                    >
                                      {subcategory.name}
                                    </SelectItem>
                                  ))}
                                </ScrollArea>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="salesChannels"
                      render={() => (
                        <FormItem>
                          <div className="mb-2">
                            <FormLabel>
                              Canais de Venda
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Info className="h-4 w-4 inline-block ml-2 cursor-help text-gray-400" />
                                  </TooltipTrigger>
                                  <TooltipContent className="max-w-sm">
                                    <p>Selecione todos os canais que sua empresa utiliza ou planeja utilizar para vender.</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            </FormLabel>
                          </div>
                          <Card>
                            <CardContent className="pt-4">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                {salesChannels.map((channel) => (
                                  <FormField
                                    key={channel.id}
                                    control={form.control}
                                    name="salesChannels"
                                    render={({ field }) => {
                                      return (
                                        <FormItem
                                          key={channel.id}
                                          className="flex flex-row items-start space-x-3 space-y-0"
                                        >
                                          <FormControl>
                                            <Checkbox
                                              checked={field.value?.includes(channel.id)}
                                              onCheckedChange={(checked) => {
                                                return checked
                                                  ? field.onChange([...field.value, channel.id])
                                                  : field.onChange(
                                                      field.value?.filter(
                                                        (value) => value !== channel.id
                                                      )
                                                    );
                                              }}
                                            />
                                          </FormControl>
                                          <div className="space-y-1 leading-none">
                                            <FormLabel className="font-normal cursor-pointer">
                                              {channel.name}
                                            </FormLabel>
                                            <FormDescription className="text-xs">
                                              {channel.description.length > 60 
                                                ? `${channel.description.substring(0, 60)}...` 
                                                : channel.description
                                              }
                                            </FormDescription>
                                          </div>
                                        </FormItem>
                                      );
                                    }}
                                  />
                                ))}
                              </div>
                            </CardContent>
                          </Card>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>
                  
                  {/* Aba de localização */}
                  <TabsContent value="location" className="space-y-6 pt-4">
                    <div className="grid grid-cols-1 gap-6 sm:grid-cols-3">
                      <FormField
                        control={form.control}
                        name="country"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>País</FormLabel>
                            <Select 
                              onValueChange={(value) => {
                                field.onChange(value);
                                setSelectedCountry(value);
                              }}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Selecione um país" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {countries.map((country) => (
                                  <SelectItem 
                                    key={country.id} 
                                    value={country.id}
                                  >
                                    {country.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="state"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Estado</FormLabel>
                            <Select 
                              onValueChange={(value) => {
                                field.onChange(value);
                                setSelectedState(value);
                              }}
                              value={field.value}
                              disabled={!selectedCountry}
                            >
                              <FormControl>
                                <SelectTrigger className="flex items-center">
                                  <SelectValue placeholder={selectedCountry ? "Selecione um estado" : "Selecione um país primeiro"} />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {availableStates.map((state) => (
                                  <SelectItem 
                                    key={state.id} 
                                    value={state.id}
                                  >
                                    {state.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="city"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Cidade</FormLabel>
                            <Select 
                              onValueChange={field.onChange}
                              value={field.value}
                              disabled={!selectedState}
                            >
                              <FormControl>
                                <SelectTrigger className="flex items-center">
                                  <MapPin className="w-4 h-4 mr-2 text-gray-500" />
                                  <SelectValue placeholder={selectedState ? "Selecione uma cidade" : "Selecione um estado primeiro"} />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {availableCities.map((city) => (
                                  <SelectItem 
                                    key={city.id} 
                                    value={city.id}
                                  >
                                    {city.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="p-4 bg-blue-50 rounded-md border border-blue-200 text-blue-700 text-sm">
                      <p className="flex items-center">
                        <Info className="h-4 w-4 mr-2" />
                        A localização será usada para encontrar concorrentes na mesma área geográfica que seu negócio.
                      </p>
                    </div>
                  </TabsContent>
                  
                  {/* Aba de detalhes adicionais */}
                  <TabsContent value="advanced" className="space-y-6 pt-4">
                    <FormField
                      control={form.control}
                      name="businessDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Descrição do Negócio (opcional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Descreva brevemente o seu negócio, os produtos ou serviços que oferece." 
                              className="min-h-24"
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            Essas informações ajudarão a encontrar concorrentes mais relevantes.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Accordion type="single" collapsible className="w-full">
                      <AccordionItem value="target-audience">
                        <AccordionTrigger>Público-Alvo (opcional)</AccordionTrigger>
                        <AccordionContent>
                          <FormField
                            control={form.control}
                            name="targetAudience"
                            render={({ field }) => (
                              <FormItem>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Descreva quem é o público-alvo do seu negócio (idade, gênero, interesses, nível de renda, etc)." 
                                    className="min-h-24"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </AccordionContent>
                      </AccordionItem>
                      
                      <AccordionItem value="advantages">
                        <AccordionTrigger>Vantagens Competitivas (opcional)</AccordionTrigger>
                        <AccordionContent>
                          <FormField
                            control={form.control}
                            name="competitiveAdvantages"
                            render={({ field }) => (
                              <FormItem>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Quais são os diferenciais do seu negócio? O que te destaca da concorrência?" 
                                    className="min-h-24"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </AccordionContent>
                      </AccordionItem>
                      
                      <AccordionItem value="price-range">
                        <AccordionTrigger>Faixa de Preço (opcional)</AccordionTrigger>
                        <AccordionContent>
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={form.control}
                              name="priceRange.min"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Valor Mínimo (R$)</FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="Ex: 10.00" 
                                      type="number"
                                      step="0.01"
                                      min="0"
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={form.control}
                              name="priceRange.max"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Valor Máximo (R$)</FormLabel>
                                  <FormControl>
                                    <Input 
                                      placeholder="Ex: 100.00" 
                                      type="number"
                                      step="0.01"
                                      min="0"
                                      {...field} 
                                    />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormDescription className="mt-2">
                            Indique a faixa de preço dos seus produtos ou serviços principais.
                          </FormDescription>
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>

                    <FormField
                      control={form.control}
                      name="keywords"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Palavras-chave (opcional)</FormLabel>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                              <Search className="w-4 h-4 text-gray-400" />
                            </div>
                            <FormControl>
                              <Input 
                                className="pl-10" 
                                placeholder="Separe por vírgulas (ex: café especial, torrefação)" 
                                {...field} 
                              />
                            </FormControl>
                          </div>
                          <FormDescription>
                            Adicione palavras-chave para ajudar na busca por concorrentes mais relevantes.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>
                </Tabs>

                <div className="pt-6 border-t mt-6">
                  <div className="flex flex-col items-center space-y-2">
                    <div className="flex items-center space-x-1 text-sm text-muted-foreground mb-2">
                      <Search className="h-4 w-4 text-primary" />
                      <span>Mappe</span>
                      <span className="logo-text-gradient">.ia</span>
                      <span>encontrará os melhores concorrentes para análise</span>
                    </div>
                    <Button 
                      type="submit" 
                      className="w-full md:w-1/2 bg-gradient-to-r from-primary to-purple-500 hover:from-primary/90 hover:to-purple-500/90 transition-all" 
                      size="lg"
                      disabled={searchMutation.isPending}
                    >
                      {searchMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Processando análise...
                        </>
                      ) : (
                        <>
                          <Search className="mr-2 h-5 w-5" />
                          Iniciar Pesquisa de Mercado
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </div>
  );
}
