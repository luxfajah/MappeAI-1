import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getSearch, createReport, type Competitor } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { LeafletMap } from "@/components/ui/leaflet-map";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter 
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { 
  ArrowLeft, 
  FileText, 
  Info, 
  Loader2, 
  Star, 
  Globe, 
  Facebook, 
  Instagram, 
  Twitter, 
  Store, 
  ShoppingCart, 
  ShoppingBag, 
  Hash 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function SearchResults() {
  const { id } = useParams<{ id: string }>();
  const searchId = parseInt(id || "0");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedCompetitors, setSelectedCompetitors] = useState<number[]>([]);
  const [detailedCompetitor, setDetailedCompetitor] = useState<Competitor | null>(null);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);

  // Fetch search data
  const { data, isLoading, error } = useQuery({
    queryKey: [`/api/search/${searchId}`],
    queryFn: () => getSearch(searchId),
    enabled: !isNaN(searchId),
  });

  // Select first 3 competitors by default when data is loaded
  useEffect(() => {
    if (data?.competitors && data.competitors.length > 0 && selectedCompetitors.length === 0) {
      setSelectedCompetitors(data.competitors.slice(0, 3).map(comp => comp.id));
    }
  }, [data?.competitors, selectedCompetitors.length]);

  // Generate report mutation
  const reportMutation = useMutation({
    mutationFn: ({ searchId, selectedCompetitors }: { searchId: number, selectedCompetitors: number[] }) => 
      createReport(searchId, selectedCompetitors),
    onSuccess: (data) => {
      setIsGeneratingReport(false);
      toast({
        title: "Relatório gerado com sucesso!",
        description: "Redirecionando para visualização...",
      });
      setLocation(`/report/${data.report.id}`);
    },
    onError: (error: Error) => {
      setIsGeneratingReport(false);
      toast({
        title: "Erro ao gerar relatório",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Convert competitors to map markers
  const getMapMarkers = () => {
    if (!data?.competitors) return [];
    
    return [
      // Main business marker (center)
      {
        id: 0,
        name: data.search.businessName,
        position: { 
          lat: data.competitors[0]?.coordinates?.lat || -23.550520, 
          lng: data.competitors[0]?.coordinates?.lng || -46.633308 
        },
        isMainBusiness: true
      },
      // Competitor markers
      ...data.competitors
        .filter(comp => comp.coordinates)
        .map(comp => ({
          id: comp.id,
          name: comp.name,
          position: { 
            lat: comp.coordinates?.lat || 0, 
            lng: comp.coordinates?.lng || 0 
          },
          isMainBusiness: false
        }))
    ];
  };

  // Handle competitor selection
  const toggleCompetitor = (competitorId: number) => {
    setSelectedCompetitors(prev => 
      prev.includes(competitorId)
        ? prev.filter(id => id !== competitorId)
        : [...prev, competitorId]
    );
  };

  // Show competitor details
  const showCompetitorDetails = (competitor: Competitor) => {
    setDetailedCompetitor(competitor);
  };

  // Generate report
  const handleGenerateReport = () => {
    if (selectedCompetitors.length === 0) {
      toast({
        title: "Selecione concorrentes",
        description: "Por favor, selecione pelo menos um concorrente para gerar o relatório.",
        variant: "destructive",
      });
      return;
    }
    
    setIsGeneratingReport(true);
    reportMutation.mutate({ searchId, selectedCompetitors });
  };

  // Render channel icon
  const renderChannelIcon = (channel: string) => {
    if (channel.includes("Física")) return <Store className="mr-1 h-3 w-3" />;
    if (channel.includes("E-commerce")) return <ShoppingCart className="mr-1 h-3 w-3" />;
    if (channel.includes("Marketplace")) return <ShoppingBag className="mr-1 h-3 w-3" />;
    if (channel.includes("Sociais")) return <Instagram className="mr-1 h-3 w-3" />;
    return <Hash className="mr-1 h-3 w-3" />;
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Error state
  if (error || !data) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-xl text-destructive">Erro ao carregar resultados</CardTitle>
            <CardDescription>
              {error instanceof Error ? error.message : "Não foi possível encontrar os dados desta pesquisa."}
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => setLocation("/dashboard")}>Voltar ao Dashboard</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon"
                className="mr-4 text-gray-500 hover:text-primary-600" 
                onClick={() => setLocation("/search/new")}
              >
                <ArrowLeft />
              </Button>
              <div>
                <h1 className="font-heading text-2xl font-bold text-gray-900">Resultados da Pesquisa</h1>
                <p className="mt-1 text-sm text-gray-500">
                  {data.search.businessName} - {data.search.location}
                </p>
              </div>
            </div>
            <div className="mt-4 sm:mt-0">
              <Button 
                onClick={handleGenerateReport}
                disabled={isGeneratingReport || selectedCompetitors.length === 0}
              >
                {isGeneratingReport ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Gerando...
                  </>
                ) : (
                  <>
                    <FileText className="mr-2 h-4 w-4" />
                    Gerar Relatório
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Map and Competitors Section */}
      <div className="bg-gray-100 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="flex flex-col md:flex-row">
              {/* Map Container */}
              <div className="w-full md:w-2/3">
                <LeafletMap 
                  center={getMapMarkers()[0].position}
                  businessName={data.search.businessName}
                  competitors={data.competitors}
                  onMarkerClick={(competitor) => {
                    showCompetitorDetails(competitor);
                  }}
                />
              </div>
              
              {/* Competitors List */}
              <div className="w-full md:w-1/3 border-t md:border-t-0 md:border-l border-gray-200">
                <div className="p-4 border-b border-gray-200 bg-gray-50">
                  <h3 className="font-heading text-lg font-medium text-gray-900">Concorrentes Encontrados</h3>
                  <p className="text-sm text-gray-500">Selecione os que deseja incluir no relatório</p>
                </div>
                <div className="h-96 overflow-y-auto">
                  <ul className="divide-y divide-gray-200">
                    {data.competitors.map((competitor) => (
                      <li key={competitor.id} className="p-4 hover:bg-gray-50">
                        <div className="flex items-start">
                          <div className="flex-shrink-0 mt-1">
                            <Checkbox
                              id={`competitor-${competitor.id}`}
                              checked={selectedCompetitors.includes(competitor.id)}
                              onCheckedChange={() => toggleCompetitor(competitor.id)}
                            />
                          </div>
                          <label 
                            htmlFor={`competitor-${competitor.id}`} 
                            className="ml-3 flex-1 cursor-pointer"
                          >
                            <div className="font-medium text-gray-900">{competitor.name}</div>
                            <div className="text-sm text-gray-500">{competitor.distance}</div>
                            <div className="mt-1">
                              <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-100">
                                {competitor.rating} <Star className="ml-1 h-3 w-3 fill-yellow-400 text-yellow-400" />
                              </Badge>
                            </div>
                          </label>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="ml-2 text-primary-600 hover:text-primary-700"
                            onClick={() => showCompetitorDetails(competitor)}
                          >
                            <Info className="h-4 w-4" />
                          </Button>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Info Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <h2 className="font-heading text-xl font-bold text-gray-900 mb-4">Detalhes dos Concorrentes</h2>
        
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Nome</TableHead>
                  <TableHead>Ticket Médio</TableHead>
                  <TableHead>Tempo de Atuação</TableHead>
                  <TableHead>Avaliação</TableHead>
                  <TableHead>Canais</TableHead>
                  <TableHead>Links</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.competitors.map((competitor) => (
                  <TableRow key={competitor.id}>
                    <TableCell className="font-medium">{competitor.name}</TableCell>
                    <TableCell>{competitor.ticketPrice}</TableCell>
                    <TableCell>{competitor.operationTime || "Não disponível"}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-green-100 text-green-800">
                        {competitor.rating} <Star className="ml-1 h-3 w-3 fill-yellow-400 text-yellow-400" />
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {competitor.salesChannels.map((channel, idx) => (
                          <Badge key={idx} variant="outline" className="flex items-center">
                            {renderChannelIcon(channel)}
                            <span className="text-xs">{channel.split(' ')[0]}</span>
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        {competitor.links?.website && (
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <a 
                                  href={competitor.links.website} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-primary-600 hover:text-primary-700"
                                >
                                  <Globe className="h-4 w-4" />
                                </a>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>Website</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        )}
                        {competitor.links?.social?.map((social, idx) => {
                          let icon = <Instagram className="h-4 w-4" />;
                          let socialName = "Instagram";
                          
                          if (social.includes('facebook')) {
                            icon = <Facebook className="h-4 w-4" />;
                            socialName = "Facebook";
                          } else if (social.includes('twitter')) {
                            icon = <Twitter className="h-4 w-4" />;
                            socialName = "Twitter";
                          } else if (social.includes('linkedin')) {
                            icon = <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                            </svg>;
                            socialName = "LinkedIn";
                          } else if (social.includes('youtube')) {
                            icon = <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                            </svg>;
                            socialName = "YouTube";
                          } else if (social.includes('tiktok')) {
                            icon = <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                              <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
                            </svg>;
                            socialName = "TikTok";
                          }
                          
                          return (
                            <TooltipProvider key={idx}>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <a 
                                    href={social} 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="text-primary-600 hover:text-primary-700"
                                  >
                                    {icon}
                                  </a>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{socialName}</p>
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          );
                        })}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>

      {/* Competitor Detail Dialog */}
      <Dialog open={!!detailedCompetitor} onOpenChange={(open) => !open && setDetailedCompetitor(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{detailedCompetitor?.name}</DialogTitle>
            <DialogDescription>Detalhes do concorrente</DialogDescription>
          </DialogHeader>
          
          {detailedCompetitor && (
            <>
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-500">Avaliação:</span>
                  <span className="inline-flex items-center text-sm font-medium text-green-700">
                    {detailedCompetitor.rating} <Star className="ml-1 h-3 w-3 fill-yellow-400 text-yellow-400" />
                    <span className="text-gray-500 ml-1">
                      ({detailedCompetitor.reviewCount || 0} avaliações)
                    </span>
                  </span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-500">Ticket Médio:</span>
                  <span className="text-sm font-medium">{detailedCompetitor.ticketPrice}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-gray-500">Tempo de Atuação:</span>
                  <span className="text-sm font-medium">{detailedCompetitor.operationTime || "Não disponível"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Distância:</span>
                  <span className="text-sm font-medium">{detailedCompetitor.distance}</span>
                </div>
              </div>
              
              <div className="mb-4">
                <h4 className="text-sm font-medium text-gray-700 mb-2">Canais de Venda</h4>
                <div className="flex flex-wrap gap-2">
                  {detailedCompetitor.salesChannels.map((channel, idx) => (
                    <Badge key={idx} variant="outline" className="flex items-center">
                      {renderChannelIcon(channel)}
                      {channel}
                    </Badge>
                  ))}
                </div>
              </div>
              
              {detailedCompetitor.differentiators && detailedCompetitor.differentiators.length > 0 && (
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Diferenciais</h4>
                  <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                    {detailedCompetitor.differentiators.map((diff, idx) => (
                      <li key={idx}>{diff}</li>
                    ))}
                  </ul>
                </div>
              )}
              
              {(detailedCompetitor.links?.website || detailedCompetitor.links?.social) && (
                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Links</h4>
                  <div className="flex space-x-3">
                    {detailedCompetitor.links.website && (
                      <a 
                        href={detailedCompetitor.links.website} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary-600 hover:text-primary-700"
                      >
                        <Globe className="h-5 w-5" />
                      </a>
                    )}
                    {detailedCompetitor.links.social?.map((social, idx) => {
                      let icon = <Instagram className="h-5 w-5" />;
                      let socialName = "Instagram";
                      
                      if (social.includes('facebook')) {
                        icon = <Facebook className="h-5 w-5" />;
                        socialName = "Facebook";
                      } else if (social.includes('twitter')) {
                        icon = <Twitter className="h-5 w-5" />;
                        socialName = "Twitter";
                      } else if (social.includes('linkedin')) {
                        icon = <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                        </svg>;
                      } else if (social.includes('youtube')) {
                        icon = <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                        </svg>;
                      } else if (social.includes('tiktok')) {
                        icon = <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
                        </svg>;
                      }
                      
                      return (
                        <TooltipProvider key={idx}>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <a 
                                key={idx}
                                href={social} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-primary-600 hover:text-primary-700"
                              >
                                {icon}
                              </a>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{socialName}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailedCompetitor(null)}>
              Fechar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
