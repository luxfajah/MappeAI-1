import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { getReport, getSearch, type Competitor } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { PDFReport } from "@/components/ui/pdf-report";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";

export default function ReportView() {
  const { id } = useParams();
  const reportId = parseInt(id);
  const [, setLocation] = useLocation();

  // Fetch report data
  const { 
    data: report, 
    isLoading: isLoadingReport, 
    error: reportError 
  } = useQuery({
    queryKey: [`/api/report/${reportId}`],
    queryFn: () => getReport(reportId),
    enabled: !isNaN(reportId),
  });

  // Fetch search data to get competitors
  const { 
    data: searchData, 
    isLoading: isLoadingSearch,
    error: searchError
  } = useQuery({
    queryKey: [`/api/search/${report?.searchId}`],
    queryFn: () => getSearch(report?.searchId || 0),
    enabled: !!report?.searchId,
  });

  // Get selected competitors
  const selectedCompetitors = searchData?.competitors?.filter(
    comp => report?.selectedCompetitors.includes(comp.id)
  ) || [];

  // Handle loading state
  if (isLoadingReport || isLoadingSearch) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Handle error states
  if (reportError || searchError || !report) {
    const error = reportError || searchError;
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-xl text-destructive">Erro ao carregar relatório</CardTitle>
            <CardDescription>
              {error instanceof Error ? error.message : "Não foi possível encontrar os dados deste relatório."}
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => setLocation("/dashboard")}>Voltar ao Dashboard</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon"
                className="mr-4 text-gray-500 hover:text-primary-600" 
                onClick={() => setLocation(`/search/${report.searchId}`)}
              >
                <ArrowLeft />
              </Button>
              <div>
                <h1 className="font-heading text-2xl font-bold text-gray-900">Relatório de Análise</h1>
                <p className="mt-1 text-sm text-gray-500">{report.title}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Report Content */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {searchData && (
          <PDFReport
            businessName={searchData.search.businessName}
            location={searchData.search.location}
            createdAt={report.createdAt}
            competitors={selectedCompetitors}
            content={report.content}
          />
        )}
      </div>
    </div>
  );
}
