import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { 
  Card, 
  CardContent, 
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { getUserSearches, getUserReports, getPlanStatus } from "@/lib/api";
import { 
  Search, 
  FileText, 
  PieChart, 
  Eye, 
  Download, 
  LogOut, 
  ChevronRight,
  Loader2 
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { pt } from "date-fns/locale";

export default function Dashboard() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Fetch searches, reports, and plan status
  const { 
    data: searches, 
    isLoading: isLoadingSearches 
  } = useQuery({
    queryKey: ["/api/searches"],
    queryFn: () => getUserSearches(),
  });
  
  const { 
    data: reports, 
    isLoading: isLoadingReports 
  } = useQuery({
    queryKey: ["/api/reports"],
    queryFn: () => getUserReports(),
  });
  
  const { 
    data: planStatus, 
    isLoading: isLoadingPlan 
  } = useQuery({
    queryKey: ["/api/plan"],
    queryFn: () => getPlanStatus(),
  });
  
  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        setLocation("/");
      }
    });
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Navbar */}
      <nav className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <span className="font-heading font-bold text-xl text-primary-600">Chamad Mappe.ia</span>
              </div>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-8">
              <span className="text-sm text-gray-500">
                Olá, {user?.name || user?.username}
              </span>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
              >
                <LogOut className="h-4 w-4 mr-2" />
                {logoutMutation.isPending ? "Saindo..." : "Sair"}
              </Button>
            </div>
            <div className="flex items-center sm:hidden">
              <button
                type="button"
                className="text-gray-500 hover:text-primary-600"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                <i className="fas fa-bars text-xl"></i>
              </button>
            </div>
          </div>
        </div>
        
        {/* Mobile menu */}
        <div className={`sm:hidden bg-white border-t border-gray-200 py-2 ${mobileMenuOpen ? 'block' : 'hidden'}`}>
          <div className="space-y-1 px-4">
            <div className="px-3 py-2 text-base font-medium text-gray-500">
              Olá, {user?.name || user?.username}
            </div>
            <Button 
              variant="ghost"
              className="w-full justify-start"
              onClick={handleLogout}
              disabled={logoutMutation.isPending}
            >
              <LogOut className="h-4 w-4 mr-2" />
              {logoutMutation.isPending ? "Saindo..." : "Sair"}
            </Button>
          </div>
        </div>
      </nav>

      {/* Dashboard Content */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="font-heading text-2xl font-bold text-gray-900">Dashboard</h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {/* Card 1: Nova Pesquisa */}
          <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setLocation("/search/new")}>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-primary-100 rounded-md p-3">
                  <Search className="text-primary-600 h-6 w-6" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Nova Pesquisa</dt>
                    <dd>
                      <div className="text-lg font-medium text-gray-900">Iniciar</div>
                    </dd>
                  </dl>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-gray-50 px-6 py-3">
              <div className="text-sm">
                <a href="#" className="font-medium text-primary-600 hover:text-primary-500 flex items-center">
                  Encontre concorrentes <ChevronRight className="h-4 w-4 ml-1" />
                </a>
              </div>
            </CardFooter>
          </Card>

          {/* Card 2: Meus Relatórios */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-secondary-50 rounded-md p-3">
                  <FileText className="text-secondary-500 h-6 w-6" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Meus Relatórios</dt>
                    <dd>
                      {isLoadingReports ? (
                        <div className="h-8 flex items-center">
                          <Loader2 className="h-5 w-5 text-gray-400 animate-spin" />
                        </div>
                      ) : (
                        <div className="text-lg font-medium text-gray-900">
                          {reports?.length || 0} relatórios
                        </div>
                      )}
                    </dd>
                  </dl>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-gray-50 px-6 py-3">
              <div className="text-sm">
                <a href="#reports" className="font-medium text-secondary-600 hover:text-secondary-500 flex items-center">
                  Ver todos <ChevronRight className="h-4 w-4 ml-1" />
                </a>
              </div>
            </CardFooter>
          </Card>

          {/* Card 3: Status do Plano */}
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-orange-100 rounded-md p-3">
                  <PieChart className="text-orange-500 h-6 w-6" />
                </div>
                <div className="ml-5 w-0 flex-1">
                  <dl>
                    <dt className="text-sm font-medium text-gray-500 truncate">Status do Plano</dt>
                    <dd>
                      {isLoadingPlan ? (
                        <div className="h-8 flex items-center">
                          <Loader2 className="h-5 w-5 text-gray-400 animate-spin" />
                        </div>
                      ) : (
                        <div className="text-lg font-medium text-gray-900 capitalize">
                          {planStatus?.planType}
                        </div>
                      )}
                    </dd>
                  </dl>
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-gray-50 px-6 py-3">
              <div className="text-sm">
                {isLoadingPlan ? (
                  <span className="text-gray-400">Carregando...</span>
                ) : (
                  <a href="#" className="font-medium text-orange-600 hover:text-orange-500 flex items-center">
                    {planStatus?.remaining}/{planStatus?.limit} pesquisas restantes <ChevronRight className="h-4 w-4 ml-1" />
                  </a>
                )}
              </div>
            </CardFooter>
          </Card>
        </div>

        {/* Recent Reports Section */}
        <div className="mt-8" id="reports">
          <h2 className="font-heading text-lg font-medium text-gray-900">Relatórios recentes</h2>
          
          {isLoadingReports ? (
            <div className="mt-4 flex justify-center p-6 bg-white shadow rounded-lg">
              <Loader2 className="h-8 w-8 text-primary-600 animate-spin" />
            </div>
          ) : reports && reports.length > 0 ? (
            <div className="mt-4 bg-white shadow rounded-lg overflow-hidden">
              <ul className="divide-y divide-gray-200">
                {reports.slice(0, 5).map((report) => (
                  <li key={report.id}>
                    <div className="px-4 py-4 sm:px-6 hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="flex-shrink-0">
                            <FileText className="text-red-500 h-5 w-5" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{report.title}</div>
                            <div className="text-sm text-gray-500">
                              Criado {formatDistanceToNow(new Date(report.createdAt), { addSuffix: true, locale: pt })}
                            </div>
                          </div>
                        </div>
                        <div className="ml-2 flex-shrink-0 flex">
                          <Button 
                            variant="outline" 
                            size="sm"
                            className="mr-2"
                            onClick={() => setLocation(`/report/${report.id}`)}
                          >
                            <Eye className="h-4 w-4 mr-1" /> Ver
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                          >
                            <Download className="h-4 w-4 mr-1" /> Download
                          </Button>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <div className="mt-4 bg-white shadow rounded-lg p-6 text-center">
              <p className="text-gray-500">Você ainda não possui relatórios.</p>
              <Button 
                variant="link" 
                onClick={() => setLocation("/search/new")} 
                className="mt-2"
              >
                Criar sua primeira pesquisa
              </Button>
            </div>
          )}
        </div>
        
        {/* Recent Searches Section */}
        <div className="mt-8">
          <h2 className="font-heading text-lg font-medium text-gray-900">Pesquisas recentes</h2>
          
          {isLoadingSearches ? (
            <div className="mt-4 flex justify-center p-6 bg-white shadow rounded-lg">
              <Loader2 className="h-8 w-8 text-primary-600 animate-spin" />
            </div>
          ) : searches && searches.length > 0 ? (
            <div className="mt-4 bg-white shadow rounded-lg overflow-hidden">
              <ul className="divide-y divide-gray-200">
                {searches.slice(0, 5).map((search) => (
                  <li key={search.id}>
                    <div className="px-4 py-4 sm:px-6 hover:bg-gray-50 transition-colors cursor-pointer"
                         onClick={() => setLocation(`/search/${search.id}`)}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="flex-shrink-0">
                            <Search className="text-primary-500 h-5 w-5" />
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-gray-900">{search.businessName}</div>
                            <div className="text-sm text-gray-500">
                              {search.businessType} - {search.location}
                            </div>
                          </div>
                        </div>
                        <div>
                          <ChevronRight className="h-5 w-5 text-gray-400" />
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <div className="mt-4 bg-white shadow rounded-lg p-6 text-center">
              <p className="text-gray-500">Você ainda não realizou pesquisas.</p>
              <Button 
                variant="link" 
                onClick={() => setLocation("/search/new")} 
                className="mt-2"
              >
                Fazer sua primeira pesquisa
              </Button>
            </div>
          )}
        </div>
      </div>
      
      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <p className="text-center text-sm text-gray-500">
            &copy; 2023 Chamad Mappe.ia. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}
