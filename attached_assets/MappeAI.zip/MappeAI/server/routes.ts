import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { CompetitorAnalysisResult, generateCompetitorsList, generateCompetitorsReport } from "./openai";
import { setupAuth } from "./auth";
import { PLAN_LIMITS } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Check user search limit
  const checkSearchLimit = async (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const user = await storage.getUser(req.user.id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    const limit = PLAN_LIMITS[user.planType as keyof typeof PLAN_LIMITS];
    const searchesUsed = user.searchesUsed || 0;
    
    if (searchesUsed >= limit) {
      return res.status(403).json({ 
        message: "Search limit reached", 
        limit,
        used: searchesUsed,
        planType: user.planType
      });
    }
    
    next();
  };

  // Search API endpoints
  app.post("/api/search", checkSearchLimit, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const search = await storage.createSearch({
        ...req.body,
        userId: req.user.id
      });
      
      // Update user search count
      await storage.updateUserSearchCount(req.user.id);
      
      // Generate competitors using AI
      const competitors = await generateCompetitorsList(
        search.businessName,
        search.businessType,
        search.location,
        search.salesChannels || [],
        search.additionalInfo as string
      );
      
      // Store each competitor
      const savedCompetitors = [];
      for (const comp of competitors) {
        const savedComp = await storage.createCompetitor({
          searchId: search.id,
          name: comp.name,
          distance: comp.distance,
          rating: comp.rating,
          reviewCount: comp.reviewCount || 0,
          ticketPrice: comp.ticketPrice,
          operationTime: comp.operationTime || "",
          salesChannels: comp.salesChannels || [],
          location: search.location,
          placeId: "",
          coordinates: comp.coordinates || null,
          links: comp.links || null,
          differentiators: comp.differentiators || []
        });
        savedCompetitors.push(savedComp);
      }
      
      res.status(201).json({
        search,
        competitors: savedCompetitors
      });
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error creating search",
        error: error.message
      });
    }
  });
  
  app.get("/api/search/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const searchId = parseInt(req.params.id);
      const search = await storage.getSearch(searchId);
      
      if (!search) {
        return res.status(404).json({ message: "Search not found" });
      }
      
      if (search.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const competitors = await storage.getCompetitorsBySearch(searchId);
      
      res.json({
        search,
        competitors
      });
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching search",
        error: error.message
      });
    }
  });
  
  app.get("/api/searches", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const searches = await storage.getUserSearches(req.user.id);
      res.json(searches);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching searches",
        error: error.message
      });
    }
  });
  
  // Report API endpoints
  app.post("/api/report", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const { searchId, selectedCompetitors } = req.body;
      
      const search = await storage.getSearch(parseInt(searchId));
      if (!search) {
        return res.status(404).json({ message: "Search not found" });
      }
      
      if (search.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      // Get all competitors for this search
      const allCompetitors = await storage.getCompetitorsBySearch(parseInt(searchId));
      
      // Filter selected competitors
      const selectedComps = allCompetitors.filter(comp => 
        selectedCompetitors.includes(comp.id)
      );
      
      // Convert to CompetitorAnalysisResult format
      const competitors: CompetitorAnalysisResult[] = selectedComps.map(comp => ({
        name: comp.name,
        distance: comp.distance || "",
        rating: comp.rating || "",
        reviewCount: comp.reviewCount || 0,
        ticketPrice: comp.ticketPrice || "",
        operationTime: comp.operationTime || "",
        salesChannels: comp.salesChannels || [],
        coordinates: comp.coordinates as any || undefined,
        links: comp.links as any || undefined,
        differentiators: comp.differentiators || []
      }));
      
      // Generate report content
      const reportContent = await generateCompetitorsReport(
        search.businessName,
        search.businessType,
        search.location,
        competitors,
        search.additionalInfo as string
      );
      
      // Create report
      const report = await storage.createReport({
        searchId: parseInt(searchId),
        userId: req.user.id,
        title: `${search.businessName} - ${search.location}`,
        summary: reportContent.executiveSummary,
        content: reportContent,
        selectedCompetitors: selectedCompetitors
      });
      
      res.status(201).json({
        report,
        content: reportContent
      });
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error generating report",
        error: error.message
      });
    }
  });
  
  app.get("/api/report/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const reportId = parseInt(req.params.id);
      const report = await storage.getReport(reportId);
      
      if (!report) {
        return res.status(404).json({ message: "Report not found" });
      }
      
      if (report.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      res.json(report);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching report",
        error: error.message
      });
    }
  });
  
  app.get("/api/reports", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const reports = await storage.getUserReports(req.user.id);
      res.json(reports);
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching reports",
        error: error.message
      });
    }
  });
  
  // Plan status endpoint
  app.get("/api/plan", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const limit = PLAN_LIMITS[user.planType as keyof typeof PLAN_LIMITS];
      const searchesUsed = user.searchesUsed || 0;
      
      res.json({
        planType: user.planType,
        searchesUsed: searchesUsed,
        limit,
        remaining: Math.max(0, limit - searchesUsed)
      });
    } catch (error: any) {
      res.status(500).json({ 
        message: "Error fetching plan status",
        error: error.message
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
