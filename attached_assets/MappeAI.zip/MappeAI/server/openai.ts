import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface CompetitorAnalysisResult {
  name: string;
  distance: string;
  rating: string;
  reviewCount?: number;
  ticketPrice: string;
  operationTime?: string;
  salesChannels: string[];
  coordinates?: {
    lat: number;
    lng: number;
  };
  links?: {
    website?: string;
    social?: string[];
  };
  differentiators?: string[];
}

export interface ReportContent {
  executiveSummary: string;
  competitiveInsights: {
    priceRange: {
      low: number;
      high: number;
      currency: string;
    };
    ratings: {
      competitor: string;
      rating: number;
    }[];
    channelsUsage: {
      channel: string;
      percentage: number;
    }[];
  };
  keyDifferentiators: {
    competitor: string;
    strengths: string[];
  }[];
  marketTrends: {
    growthRate: number;
    currentTrends: string[];
    popularKeywords: {
      keyword: string;
      searchVolume: number;
      competition: number;
    }[];
    seasonalFactors: string[];
    emergingOpportunities: string[];
  };
  consumerAnalytics: {
    demographics: {
      ageGroups: {
        group: string;
        percentage: number;
      }[];
      genderDistribution: {
        gender: string;
        percentage: number;
      }[];
      incomeRanges: {
        range: string;
        percentage: number;
      }[];
    };
    behaviors: {
      name: string;
      description: string;
      relevanceScore: number;
    }[];
    purchasingPatterns: string[];
  };
  localCompetitionMap: {
    geographicDistribution: string;
    hotspots: string[];
    marketGaps: string[];
  };
  recommendations: string[];
}

// Import the city data
import { cidadesBrasileiras, obterCoordenadas, formatarCidade } from '../client/src/lib/cidades-brasileiras';

// Function to generate sample competitors when OpenAI API is unavailable
function generateSampleCompetitors(
  businessName: string,
  businessType: string,
  location: string,
  salesChannels: string[]
): CompetitorAnalysisResult[] {
  // Dados mais realistas de nomes de empresas brasileiras por segmento
  const businessTypes: Record<string, string[]> = {
    default: ["Empresa Brasileira", "Comércio Nacional", "Grupo Conexão", "Brasil Empreendimentos", "Central Negócios"],
    "cafeteria": ["Café do Ponto", "Grão Gourmet", "Aroma Brasil Café", "Casa do Café", "Café Express Brasil"],
    "restaurante": ["Sabor Carioca", "Tempero Mineiro", "Brasil Sabor", "Comida Caseira", "Delícias da Terra"],
    "academia": ["Smart Fit", "Bodytech", "BluesFit", "Total Fitness", "Companhia Athlética"],
    "supermercado": ["Pão de Açúcar", "Extra", "Carrefour", "Dia Brasil", "Assaí Atacadista"],
    "padaria": ["Padaria Real", "Panificadora Moderna", "Pão & Cia", "Sabor do Trigo", "Delícias do Pão"],
    "lanchonete": ["Rei do Lanche", "Sabor Express", "Delícia Lanches", "Ponto do Lanche", "Lancheria Brasil"],
    "salão de beleza": ["Beleza Pura", "Espaço Beleza", "Viva Cabelo", "Studio Hair", "Belle Femme"],
    "loja de roupas": ["Lojas Renner", "Riachuelo", "C&A", "Marisa", "Lojas Americanas"],
    "farmácia": ["Drogaria São Paulo", "Raia Drogasil", "Pague Menos", "Droga Natura", "Farmácia Popular"],
    "bar": ["Bar do Juarez", "Boteco Original", "Cervejaria Nacional", "Chopp Brasil", "Bar & Cia"],
    "pizzaria": ["Pizzaria Originale", "Pizzas Brasil", "La Vera Pizza", "Dom Pizzaiolo", "Sabor de Pizza"]
  };
  
  const type = businessType.toLowerCase();
  // Choose most specific match or fall back to default
  const matchingCategory = Object.keys(businessTypes)
    .filter(key => type.includes(key))
    .sort((a, b) => b.length - a.length)[0] || 'default';
  
  const names = businessTypes[matchingCategory] || businessTypes.default;
  
  // Encontrar a cidade nas coordenadas
  const cidadeObj = cidadesBrasileiras.find(cidade => 
    location.toLowerCase().includes(cidade.nome.toLowerCase()) ||
    formatarCidade(cidade).toLowerCase().includes(location.toLowerCase())
  );
  
  // Se não encontrar a cidade, usar São Paulo como padrão
  const baseCoordinates = cidadeObj?.coordenadas || { lat: -23.5505, lng: -46.6333 };
  
  return names.map((name, index) => {
    // Criar distância mais realista baseada no tamanho da cidade
    const populacao = cidadeObj?.populacao || 12000000;
    const maxDistance = populacao > 5000000 ? 15 : populacao > 1000000 ? 10 : 5;
    const distance = (Math.random() * maxDistance + 0.2).toFixed(1) + " km";
    
    // Rating mais realista
    const rating = (Math.random() * 1.5 + 3.5).toFixed(1);
    const reviewCount = Math.floor(Math.random() * 300) + 5;
    
    // Preços mais realistas por categoria
    let lowPrice = 0, highPrice = 0;
    
    if (matchingCategory === 'cafeteria' || matchingCategory === 'lanchonete') {
      lowPrice = Math.floor(Math.random() * 10) + 8; // 8-18 reais
      highPrice = lowPrice + Math.floor(Math.random() * 15) + 5; // +5-20 reais
    } else if (matchingCategory === 'restaurante' || matchingCategory === 'pizzaria') {
      lowPrice = Math.floor(Math.random() * 15) + 25; // 25-40 reais
      highPrice = lowPrice + Math.floor(Math.random() * 30) + 10; // +10-40 reais
    } else if (matchingCategory === 'academia') {
      lowPrice = Math.floor(Math.random() * 50) + 70; // 70-120 reais
      highPrice = lowPrice + Math.floor(Math.random() * 80) + 30; // +30-110 reais
    } else {
      lowPrice = Math.floor(Math.random() * 40) + 20; // 20-60 reais
      highPrice = lowPrice + Math.floor(Math.random() * 50) + 10; // +10-60 reais
    }
    
    const ticketPrice = `R$ ${lowPrice}-${highPrice}`;
    
    // Tempo de operação mais realista
    const operationYears = Math.floor(Math.random() * 12) + 1;
    const operationTime = `${operationYears} ${operationYears === 1 ? 'ano' : 'anos'}`;
    
    // Canais de venda mais realistas
    const availableChannels = ["Loja Física", "E-commerce", "Redes Sociais", "Marketplaces", "Aplicativo", "WhatsApp", "Telefone"];
    
    // Distribuir proporcionalmente os canais com base no tipo de negócio
    let channelProbabilities: Record<string, number> = {};
    
    if (matchingCategory === 'cafeteria' || matchingCategory === 'restaurante' || matchingCategory === 'bar') {
      channelProbabilities = {
        "Loja Física": 0.95, 
        "E-commerce": 0.3,
        "Redes Sociais": 0.8,
        "Aplicativo": 0.4,
        "WhatsApp": 0.7,
        "Telefone": 0.6
      };
    } else if (matchingCategory === 'loja de roupas' || matchingCategory === 'supermercado') {
      channelProbabilities = {
        "Loja Física": 0.9, 
        "E-commerce": 0.7,
        "Redes Sociais": 0.6,
        "Marketplaces": 0.5,
        "Aplicativo": 0.3,
        "WhatsApp": 0.2
      };
    } else {
      channelProbabilities = {
        "Loja Física": 0.8, 
        "E-commerce": 0.5,
        "Redes Sociais": 0.7,
        "Marketplaces": 0.3,
        "WhatsApp": 0.4,
        "Telefone": 0.5
      };
    }
    
    // Selecionar canais com base nas probabilidades
    const selectedChannels = Object.entries(channelProbabilities)
      .filter(([_, probability]) => Math.random() < probability)
      .map(([channel, _]) => channel);
    
    // Garantir pelo menos um canal
    if (selectedChannels.length === 0) {
      selectedChannels.push("Loja Física");
    }
    
    // Coordenadas - espalhamento mais realista ao redor da cidade
    const popularPlaces = [0.01, 0.015, 0.005, 0.008, 0.012]; // Áreas mais populares
    const spread = popularPlaces[Math.floor(Math.random() * popularPlaces.length)];
    const direction = Math.random() * Math.PI * 2; // Direção aleatória em radianos
    
    const latOffset = Math.cos(direction) * spread * (Math.random() + 0.5);
    const lngOffset = Math.sin(direction) * spread * (Math.random() + 0.5);
    
    const coords = {
      lat: baseCoordinates.lat + latOffset,
      lng: baseCoordinates.lng + lngOffset
    };
    
    // Diferenciais mais específicos por tipo de negócio
    let diffOptions: string[] = [];
    
    if (matchingCategory === 'cafeteria') {
      diffOptions = [
        "Café de origem única", "Métodos de preparo especiais", "Ambiente para trabalho remoto",
        "Grãos torrados na loja", "Opções veganas", "Produtos orgânicos", "Wi-Fi gratuito",
        "Cafés especiais importados", "Ambiente pet friendly", "Espaço para eventos"
      ];
    } else if (matchingCategory === 'restaurante') {
      diffOptions = [
        "Buffet self-service", "Pratos exclusivos", "Chef renomado", "Menu degustação",
        "Ambiente gourmet", "Ingredientes orgânicos", "Culinária especializada",
        "Área kids", "Música ao vivo", "Reserva online", "Delivery próprio"
      ];
    } else if (matchingCategory === 'academia') {
      diffOptions = [
        "Aulas coletivas inclusas", "Planos flexíveis", "Área de musculação completa",
        "Personal trainer", "Equipamentos importados", "Academia 24h", "Área de cardio",
        "Estúdio de pilates", "Crossfit", "Avaliação física gratuita"
      ];
    } else {
      diffOptions = [
        "Atendimento personalizado", "Preços competitivos", "Produtos exclusivos",
        "Entrega rápida", "Forte presença online", "Variedade de produtos",
        "Qualidade superior", "Promoções frequentes", "Programa de fidelidade",
        "Localização privilegiada", "Estacionamento próprio", "Horário estendido"
      ];
    }
    
    // Selecionar 2-4 diferenciais aleatórios
    const diffCount = Math.floor(Math.random() * 3) + 2;
    const differentiators = [...diffOptions]
      .sort(() => 0.5 - Math.random())
      .slice(0, diffCount);
    
    // Gerar URLs mais realistas
    const cleanName = name.toLowerCase()
      .normalize("NFD").replace(/[\u0300-\u036f]/g, "") // Remover acentos
      .replace(/[^a-z0-9]/g, ""); // Remover caracteres especiais
    
    const domains = [".com.br", ".com", ".net.br", ".net"];
    const domain = domains[Math.floor(Math.random() * domains.length)];
    
    // Usar sites reais para empresas conhecidas
    let website = "";
    
    if (name === "Pão de Açúcar") {
      website = "https://www.paodeacucar.com";
    } else if (name === "Extra") {
      website = "https://www.extra.com.br";
    } else if (name === "Carrefour") {
      website = "https://www.carrefour.com.br";
    } else if (name === "Assaí Atacadista") {
      website = "https://www.assai.com.br";
    } else if (name === "Smart Fit") {
      website = "https://www.smartfit.com.br"; 
    } else if (name === "Bodytech") {
      website = "https://www.bodytech.com.br";
    } else if (name === "Lojas Renner") {
      website = "https://www.lojasrenner.com.br";
    } else if (name === "Riachuelo") {
      website = "https://www.riachuelo.com.br";
    } else if (name === "C&A") {
      website = "https://www.cea.com.br";
    } else if (name === "Marisa") {
      website = "https://www.marisa.com.br";
    } else if (name === "Lojas Americanas") {
      website = "https://www.americanas.com.br";
    } else if (name === "Drogaria São Paulo") {
      website = "https://www.drogariasaopaulo.com.br";
    } else if (name === "Raia Drogasil") {
      website = "https://www.drogaraia.com.br";
    } else if (name === "Pague Menos") {
      website = "https://www.paguemenos.com.br";
    } else {
      website = `https://www.${cleanName}${domain}`;
    }
    
    // Redes sociais - usar URLs reais
    const socialMap = {
      "instagram": `https://www.instagram.com/${cleanName}/`,
      "facebook": `https://www.facebook.com/${cleanName}/`,
      "twitter": `https://www.twitter.com/${cleanName}/`,
      "linkedin": `https://www.linkedin.com/company/${cleanName}/`,
      "youtube": `https://www.youtube.com/c/${cleanName}/`,
      "tiktok": `https://www.tiktok.com/@${cleanName}/`,
    };
    
    // Selecionar algumas redes sociais aleatoriamente
    const socialOptions = ["instagram", "facebook", "twitter", "linkedin", "youtube", "tiktok"];
    const socialCount = Math.floor(Math.random() * 3) + 1;
    const socialTypes = [...socialOptions]
      .sort(() => 0.5 - Math.random())
      .slice(0, socialCount);
      
    // Criar os links reais para as redes sociais selecionadas
    const social = socialTypes.map(type => socialMap[type as keyof typeof socialMap]);
    
    return {
      name,
      distance,
      rating,
      reviewCount,
      ticketPrice,
      operationTime,
      salesChannels: selectedChannels,
      coordinates: coords,
      links: {
        website,
        social
      },
      differentiators
    };
  });
}

// Function to generate a sample report
function generateSampleReport(
  businessName: string,
  businessType: string,
  location: string,
  competitors: CompetitorAnalysisResult[]
): ReportContent {
  // Extract price ranges
  const priceRanges = competitors.map(comp => {
    const [min, max] = comp.ticketPrice.replace('R$ ', '').split('-').map(Number);
    return { min, max };
  });
  
  const minPrice = Math.min(...priceRanges.map(r => r.min));
  const maxPrice = Math.max(...priceRanges.map(r => r.max));
  
  // Create ratings data
  const ratings = competitors.map(comp => ({
    competitor: comp.name,
    rating: parseFloat(comp.rating)
  }));
  
  // Calculate sales channels usage
  const channelCounts: Record<string, number> = {};
  const totalCompetitors = competitors.length;
  
  competitors.forEach(comp => {
    comp.salesChannels.forEach(channel => {
      channelCounts[channel] = (channelCounts[channel] || 0) + 1;
    });
  });
  
  const channelsUsage = Object.entries(channelCounts).map(([channel, count]) => ({
    channel,
    percentage: Math.round((count / totalCompetitors) * 100)
  }));
  
  // Create differentiators
  const keyDifferentiators = competitors.map(comp => ({
    competitor: comp.name,
    strengths: comp.differentiators || ["Boa localização", "Preços competitivos"]
  }));
  
  // Create recommendations based on the data
  const recommendations = [
    `Considere expandir sua presença nos canais ${channelsUsage[0]?.channel} e ${channelsUsage[1]?.channel}, que são amplamente utilizados pelos concorrentes.`,
    `Desenvolva uma estratégia de preços que seja competitiva, considerando a faixa média do mercado de R$ ${minPrice} a R$ ${maxPrice}.`,
    `Invista em diferenciação de produtos/serviços para destacar-se dos concorrentes como ${competitors[0]?.name} e ${competitors[1]?.name}.`,
    `Implemente um programa de fidelidade para aumentar a retenção de clientes, especialmente importante em um mercado competitivo como ${location}.`,
    `Fortaleça sua presença online e estratégia de marketing digital para aumentar a visibilidade da marca.`
  ];
  
  // Gerar dados de tendências de mercado baseados na categoria de negócio
  const businessKeywords: Record<string, string[]> = {
    default: ["marketing digital", "redes sociais", "atendimento ao cliente", "logística", "gestão de negócios"],
    "cafeteria": ["café especial", "café orgânico", "café gourmet", "coworking", "cafeteria pet friendly", "café sustentável"],
    "restaurante": ["delivery de comida", "gastronomia", "comida saudável", "chef", "experiência gastronômica", "foodtech"],
    "academia": ["fitness", "treino funcional", "musculação", "pilates", "crossfit", "personal trainer", "bem-estar"],
    "supermercado": ["compras online", "alimentos orgânicos", "atacarejo", "logística", "supermercado 24h", "produto local"],
    "padaria": ["pão artesanal", "confeitaria", "café da manhã", "brunch", "produtos sem glúten", "pão integral"],
    "lanchonete": ["lanches gourmet", "fast food", "delivery", "hambúrguer artesanal", "food truck", "comida rápida"],
    "salão de beleza": ["cabeleireiro", "tratamento capilar", "manicure", "estética", "maquiagem", "beleza natural"],
    "loja de roupas": ["moda sustentável", "e-commerce", "fast fashion", "moda plus size", "personal stylist", "moda local"],
    "farmácia": ["medicamentos genéricos", "dermocosméticos", "saúde", "farmácia delivery", "bem-estar", "manipulação"],
    "bar": ["happy hour", "drinks", "cerveja artesanal", "bar temático", "mixologia", "petiscos", "música ao vivo"],
    "pizzaria": ["pizza gourmet", "delivery de pizza", "rodízio", "massas", "pizza artesanal", "forno a lenha"]
  };

  // Escolher keywords mais específicas para o negócio
  const type = businessType.toLowerCase();
  const matchingCategory = Object.keys(businessKeywords)
    .filter(key => type.includes(key))
    .sort((a, b) => b.length - a.length)[0] || 'default';
  
  const keywords = businessKeywords[matchingCategory] || businessKeywords.default;

  // Gerar crescimento do mercado
  const growthRate = parseFloat((Math.random() * 10 + 3).toFixed(1));
  
  // Gerar tendências atuais
  const currentTrendsOptions = [
    "Crescimento do e-commerce no setor",
    "Maior exigência por qualidade de atendimento",
    "Aumento da demanda por produtos/serviços sustentáveis",
    "Maior utilização de redes sociais para divulgação",
    "Personalização da experiência do cliente",
    "Uso de tecnologia para otimizar processos",
    "Crescimento de aplicativos e plataformas mobile",
    "Aumento na preocupação com bem-estar e saúde",
    "Valorização de produtos/serviços locais",
    "Ascensão de modelos de negócio por assinatura",
    "Integração entre canais online e offline",
    "Automação de processos e atendimento"
  ];
  
  // Escolher 4-6 tendências aleatórias
  const trendCount = Math.floor(Math.random() * 3) + 4;
  const currentTrends = [...currentTrendsOptions]
    .sort(() => 0.5 - Math.random())
    .slice(0, trendCount);
  
  // Gerar keywords populares com volume de busca e competição
  const popularKeywords = keywords.map(keyword => {
    const searchVolume = Math.floor(Math.random() * 9000) + 1000;
    const competition = parseFloat((Math.random() * 0.8 + 0.2).toFixed(2));
    return { keyword, searchVolume, competition };
  });
  
  // Ordenar por volume de busca
  popularKeywords.sort((a, b) => b.searchVolume - a.searchVolume);
  
  // Gerar fatores sazonais
  const seasonalFactors = [
    `Aumento de ${Math.floor(Math.random() * 40) + 20}% nas vendas durante o período de ${Math.random() > 0.5 ? 'dezembro a janeiro' : 'novembro a dezembro'}`,
    `Queda de tráfego no período de ${Math.random() > 0.5 ? 'fevereiro' : 'julho'}, comum no setor`,
    `Pico de buscas online por ${businessType} entre ${Math.random() > 0.5 ? 'setembro e novembro' : 'março e maio'}`,
    `Aumento de interesse em ${keywords[0]} durante ${Math.random() > 0.5 ? 'eventos locais' : 'feriados prolongados'}`
  ];
  
  // Gerar oportunidades emergentes
  const emergingOpportunitiesOptions = [
    `Expansão para novos canais digitais com foco em ${keywords[1]}`,
    `Desenvolvimento de produtos/serviços alinhados com a tendência de ${currentTrends[0].toLowerCase()}`,
    `Parcerias estratégicas com empresas complementares no setor`,
    `Exploração de nichos específicos como ${keywords[2]}`,
    `Desenvolvimento de estratégias de fidelização baseadas em dados`,
    `Investimento em marketing de conteúdo focado em ${keywords[0]}`,
    `Expansão geográfica para áreas com menor competição`,
    `Implementação de tecnologias para otimização de processos`,
    `Criação de experiências diferenciadas para o cliente`,
    `Desenvolvimento de programas de sustentabilidade como diferencial competitivo`
  ];
  
  // Escolher 3-5 oportunidades aleatórias
  const oppCount = Math.floor(Math.random() * 3) + 3;
  const emergingOpportunities = [...emergingOpportunitiesOptions]
    .sort(() => 0.5 - Math.random())
    .slice(0, oppCount);
  
  // Gerar dados demográficos
  const ageGroups = [
    { group: "18-24 anos", percentage: Math.floor(Math.random() * 15) + 5 },
    { group: "25-34 anos", percentage: Math.floor(Math.random() * 20) + 15 },
    { group: "35-44 anos", percentage: Math.floor(Math.random() * 20) + 15 },
    { group: "45-54 anos", percentage: Math.floor(Math.random() * 15) + 10 },
    { group: "55+ anos", percentage: Math.floor(Math.random() * 15) + 5 }
  ];
  
  // Ajustar para garantir que as porcentagens somem 100%
  const ageGroupSum = ageGroups.reduce((sum, group) => sum + group.percentage, 0);
  ageGroups.forEach(group => {
    group.percentage = Math.round((group.percentage / ageGroupSum) * 100);
  });
  
  // Gerar distribuição de gênero
  const genderDistribution = [
    { gender: "Masculino", percentage: Math.floor(Math.random() * 40) + 30 },
    { gender: "Feminino", percentage: 0 }
  ];
  genderDistribution[1].percentage = 100 - genderDistribution[0].percentage;
  
  // Gerar faixas de renda
  const incomeRanges = [
    { range: "Até R$ 2.000", percentage: Math.floor(Math.random() * 20) + 5 },
    { range: "R$ 2.001 - R$ 5.000", percentage: Math.floor(Math.random() * 25) + 15 },
    { range: "R$ 5.001 - R$ 10.000", percentage: Math.floor(Math.random() * 25) + 15 },
    { range: "Acima de R$ 10.000", percentage: Math.floor(Math.random() * 20) + 5 }
  ];
  
  // Ajustar para garantir que as porcentagens somem 100%
  const incomeSum = incomeRanges.reduce((sum, range) => sum + range.percentage, 0);
  incomeRanges.forEach(range => {
    range.percentage = Math.round((range.percentage / incomeSum) * 100);
  });
  
  // Gerar comportamentos do consumidor
  const behaviors = [
    {
      name: "Pesquisa online, compra offline",
      description: "Consumidores pesquisam informações online antes de visitar estabelecimentos físicos",
      relevanceScore: Math.round(Math.random() * 2 + 3)
    },
    {
      name: "Sensibilidade a preço",
      description: "Busca ativa por promoções e comparação de preços entre concorrentes",
      relevanceScore: Math.round(Math.random() * 2 + 3)
    },
    {
      name: "Valorização da experiência",
      description: "Disposição a pagar mais por experiências diferenciadas e atendimento personalizado",
      relevanceScore: Math.round(Math.random() * 2 + 3)
    },
    {
      name: "Engajamento em redes sociais",
      description: "Interação com marcas através de plataformas sociais e influência de reviews",
      relevanceScore: Math.round(Math.random() * 2 + 3)
    }
  ];
  
  // Padrões de compra
  const purchasingPatterns = [
    `Pico de compras no ${Math.random() > 0.5 ? 'início' : 'final'} do mês, coincidindo com o período de pagamento de salários`,
    `Maior movimento nos ${Math.random() > 0.5 ? 'finais de semana' : 'dias úteis em horário comercial'}`,
    `Compras recorrentes em intervalos de ${Math.floor(Math.random() * 3) + 1} ${Math.random() > 0.5 ? 'semanas' : 'meses'}`,
    `Aumento de tíquete médio em ${Math.random() > 0.5 ? 'datas comemorativas' : 'promoções sazonais'}`
  ];
  
  // Mapeamento de competição local
  const geographicDistribution = `A análise geográfica mostra uma concentração de concorrentes em ${Math.random() > 0.5 ? 'áreas centrais' : 'regiões de maior poder aquisitivo'} de ${location}, com distância média de ${(Math.random() * 3 + 1.5).toFixed(1)}km entre estabelecimentos similares.`;
  
  // Hotspots
  const hotspotsOptions = [
    `Região central com alta concentração de estabelecimentos similares`,
    `Zona comercial próxima a ${Math.random() > 0.5 ? 'shopping centers' : 'centros empresariais'}`,
    `Áreas residenciais de ${Math.random() > 0.5 ? 'alto' : 'médio'} poder aquisitivo`,
    `Proximidade a ${Math.random() > 0.5 ? 'universidades' : 'polos de negócios'}`,
    `Corredores comerciais estabelecidos`,
    `Bairros em desenvolvimento com crescimento imobiliário`
  ];
  
  // Escolher 2-3 hotspots
  const hotspotCount = Math.floor(Math.random() * 2) + 2;
  const hotspots = [...hotspotsOptions]
    .sort(() => 0.5 - Math.random())
    .slice(0, hotspotCount);
  
  // Lacunas de mercado
  const marketGapsOptions = [
    `Regiões ${Math.random() > 0.5 ? 'periféricas' : 'em desenvolvimento'} com baixa oferta de serviços similares`,
    `Segmentos de público específicos não atendidos adequadamente`,
    `Horários alternativos com baixa cobertura de serviços`,
    `Integração entre canais digitais e físicos ainda incipiente no mercado`,
    `Experiências personalizadas limitadas entre os concorrentes`,
    `Nível de atendimento ao cliente abaixo das expectativas do mercado`
  ];
  
  // Escolher 2-3 lacunas
  const gapCount = Math.floor(Math.random() * 2) + 2;
  const marketGaps = [...marketGapsOptions]
    .sort(() => 0.5 - Math.random())
    .slice(0, gapCount);
  
  // Adicionar novas recomendações baseadas nos dados de analytics
  const extendedRecommendations = [
    ...recommendations,
    `Explore palavras-chave como "${popularKeywords[0].keyword}" e "${popularKeywords[1].keyword}" em suas estratégias de marketing digital, que apresentam alto volume de busca neste segmento.`,
    `Adapte sua estratégia para capitalizar na tendência de ${currentTrends[0].toLowerCase()}, que está em ascensão no mercado.`,
    `Considere desenvolver campanhas sazonais alinhadas com ${seasonalFactors[0].toLowerCase()}.`,
    `Foque no segmento demográfico de ${ageGroups.sort((a, b) => b.percentage - a.percentage)[0].group} (${ageGroups[0].percentage}% do mercado) em suas estratégias de marketing.`
  ];

  return {
    executiveSummary: `A análise do mercado em ${location} para o segmento de ${businessType} mostra um cenário competitivo com ${competitors.length} principais concorrentes e crescimento anual de ${growthRate}%. ${businessName} enfrenta empresas estabelecidas como ${competitors[0]?.name} e ${competitors[1]?.name}, que se destacam por ${competitors[0]?.differentiators?.[0] || 'diversos fatores'} e ${competitors[1]?.differentiators?.[0] || 'qualidade de serviço'}. O ticket médio no setor varia entre R$ ${minPrice} e R$ ${maxPrice}, com classificações médias de clientes entre ${Math.min(...ratings.map(r => r.rating)).toFixed(1)} e ${Math.max(...ratings.map(r => r.rating)).toFixed(1)} estrelas. Os canais de distribuição mais utilizados são ${channelsUsage[0]?.channel} (${channelsUsage[0]?.percentage}%) e ${channelsUsage[1]?.channel} (${channelsUsage[1]?.percentage}%). As palavras-chave de maior volume de busca são "${popularKeywords[0].keyword}" e "${popularKeywords[1].keyword}", indicando tendências importantes no setor. Para se manter competitivo neste mercado, ${businessName} precisará explorar diferenciais específicos e considerar estratégias focadas em experiência do cliente, alinhadas com as tendências atuais de ${currentTrends[0].toLowerCase()}.`,
    competitiveInsights: {
      priceRange: {
        low: minPrice,
        high: maxPrice,
        currency: "R$"
      },
      ratings,
      channelsUsage
    },
    keyDifferentiators,
    marketTrends: {
      growthRate,
      currentTrends,
      popularKeywords,
      seasonalFactors,
      emergingOpportunities
    },
    consumerAnalytics: {
      demographics: {
        ageGroups,
        genderDistribution,
        incomeRanges
      },
      behaviors,
      purchasingPatterns
    },
    localCompetitionMap: {
      geographicDistribution,
      hotspots,
      marketGaps
    },
    recommendations: extendedRecommendations
  };
}

export async function generateCompetitorsList(
  businessName: string,
  businessType: string,
  location: string,
  salesChannels: string[],
  additionalInfo?: string
): Promise<CompetitorAnalysisResult[]> {
  try {
    // Parse additional info if available
    let parsedInfo = {};
    if (additionalInfo) {
      try {
        parsedInfo = JSON.parse(additionalInfo);
      } catch (e) {
        console.warn("Could not parse additionalInfo:", e);
      }
    }
    
    const { 
      competitiveAdvantages, 
      targetAudience, 
      priceRange, 
      businessDescription 
    } = parsedInfo as any;
    
    // Build prompt with additional context if available
    let additionalContext = "";
    
    if (businessDescription) {
      additionalContext += `\n- Business Description: ${businessDescription}`;
    }
    
    if (targetAudience) {
      additionalContext += `\n- Target Audience: ${targetAudience}`;
    }
    
    if (competitiveAdvantages) {
      additionalContext += `\n- Competitive Advantages: ${competitiveAdvantages}`;
    }
    
    if (priceRange) {
      additionalContext += `\n- Price Range: ${priceRange.currency || 'R$'} ${priceRange.min || 0} to ${priceRange.max || 0}`;
    }
    
    const prompt = `
      As an AI market research assistant, generate a list of 5 potential competitors for a business with the following details:
      - Business Name: ${businessName}
      - Type of Business: ${businessType}
      - Location: ${location}
      - Sales Channels: ${salesChannels.join(", ")}${additionalContext}
      
      For each competitor, provide realistic data in the following JSON format:
      {
        "competitors": [
          {
            "name": "Competitor Name",
            "distance": "X.X km",
            "rating": "X.X",
            "reviewCount": XX,
            "ticketPrice": "R$ XX-XX",
            "operationTime": "X years",
            "salesChannels": ["Physical Store", "E-commerce", etc],
            "coordinates": {"lat": XX.XXXXX, "lng": XX.XXXXX},
            "links": {"website": "url", "social": ["instagram", "facebook"]},
            "differentiators": ["unique point 1", "unique point 2"]
          }
        ]
      }
      
      Ensure all data is realistic for ${location}, especially for coordinates, business names, and other details.
      ${priceRange ? `Try to match the price range of competitors to be similar to the business's price range of ${priceRange.currency || 'R$'} ${priceRange.min || 0} to ${priceRange.max || 0}.` : ''}
      ${competitiveAdvantages ? `Consider the business's competitive advantages: "${competitiveAdvantages}" when determining competitor differentiators.` : ''}
    `;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" }
      });
  
      if (!response.choices[0].message.content) {
        throw new Error("Empty response from OpenAI API");
      }
      
      const content = JSON.parse(response.choices[0].message.content);
      return content.competitors;
    } catch (openaiError: any) {
      console.warn("OpenAI API error, using sample data instead:", openaiError.message);
      return generateSampleCompetitors(businessName, businessType, location, salesChannels);
    }
  } catch (error: any) {
    console.error("Error generating competitors:", error.message);
    // Fallback to sample data
    return generateSampleCompetitors(businessName, businessType, location, salesChannels);
  }
}

export async function generateCompetitorsReport(
  businessName: string,
  businessType: string,
  location: string,
  competitors: CompetitorAnalysisResult[],
  additionalInfo?: string
): Promise<ReportContent> {
  try {
    const competitorsData = JSON.stringify(competitors);
    
    // Parse additional info if available
    let parsedInfo = {};
    if (additionalInfo) {
      try {
        parsedInfo = JSON.parse(additionalInfo);
      } catch (e) {
        console.warn("Could not parse additionalInfo for report:", e);
      }
    }
    
    const { 
      competitiveAdvantages, 
      targetAudience, 
      priceRange, 
      businessDescription 
    } = parsedInfo as any;
    
    // Build additional context for the report if available
    let additionalContext = "";
    
    if (businessDescription) {
      additionalContext += `\nBusiness Description: ${businessDescription}`;
    }
    
    if (targetAudience) {
      additionalContext += `\nTarget Audience: ${targetAudience}`;
    }
    
    if (competitiveAdvantages) {
      additionalContext += `\nCompetitive Advantages: ${competitiveAdvantages}`;
    }
    
    if (priceRange) {
      additionalContext += `\nPrice Range: ${priceRange.currency || 'R$'} ${priceRange.min || 0} to ${priceRange.max || 0}`;
    }
    
    const prompt = `
      As an AI market analyst, create a detailed competitive analysis report for a business named "${businessName}" 
      (${businessType}) located in ${location}, based on the following competitors data:
      
      ${competitorsData}
      
      ${additionalContext ? `Additional information about the business:${additionalContext}` : ""}
      
      Generate a report with the following sections in JSON format:
      {
        "executiveSummary": "A 1-2 paragraph summary of the competitive landscape",
        "competitiveInsights": {
          "priceRange": {"low": XX, "high": XX, "currency": "R$"},
          "ratings": [{"competitor": "name", "rating": X.X}, ...],
          "channelsUsage": [{"channel": "Physical Store", "percentage": XX}, ...]
        },
        "keyDifferentiators": [
          {"competitor": "name", "strengths": ["strength 1", "strength 2", ...]},
          ...
        ],
        "recommendations": ["strategic recommendation 1", "recommendation 2", ...]
      }
      
      ${competitiveAdvantages ? `Include recommendations that leverage the business's competitive advantages: "${competitiveAdvantages}"` : ""}
      ${targetAudience ? `Focus recommendations on how to better serve or expand the target audience: "${targetAudience}"` : ""}
      ${priceRange ? `Consider the business's price range in your analysis and recommendations.` : ""}
      
      Base your analysis on factual patterns in the data and create actionable insights.
    `;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" }
      });
      
      if (!response.choices[0].message.content) {
        throw new Error("Empty response from OpenAI API");
      }
  
      return JSON.parse(response.choices[0].message.content);
    } catch (openaiError: any) {
      console.warn("OpenAI API error, using sample report instead:", openaiError.message);
      return generateSampleReport(businessName, businessType, location, competitors);
    }
  } catch (error: any) {
    console.error("Error generating report:", error.message);
    // Fallback to sample report
    return generateSampleReport(businessName, businessType, location, competitors);
  }
}
