import { users, type User, type InsertUser, searches, type Search, type InsertSearch, competitors, type Competitor, type InsertCompetitor, reports, type Report, type InsertReport, PLAN_LIMITS } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserSearchCount(userId: number): Promise<User>;
  getUserSearchCount(userId: number): Promise<number>;
  
  // Search methods
  createSearch(search: InsertSearch): Promise<Search>;
  getSearch(id: number): Promise<Search | undefined>;
  getUserSearches(userId: number): Promise<Search[]>;
  
  // Competitor methods
  createCompetitor(competitor: InsertCompetitor): Promise<Competitor>;
  getCompetitorsBySearch(searchId: number): Promise<Competitor[]>;
  
  // Report methods
  createReport(report: InsertReport): Promise<Report>;
  getReport(id: number): Promise<Report | undefined>;
  getUserReports(userId: number): Promise<Report[]>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private searches: Map<number, Search>;
  private competitors: Map<number, Competitor>;
  private reports: Map<number, Report>;
  currentUserId: number;
  currentSearchId: number;
  currentCompetitorId: number;
  currentReportId: number;
  sessionStore: session.SessionStore;

  constructor() {
    this.users = new Map();
    this.searches = new Map();
    this.competitors = new Map();
    this.reports = new Map();
    this.currentUserId = 1;
    this.currentSearchId = 1;
    this.currentCompetitorId = 1;
    this.currentReportId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24h
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser,
      id,
      planType: "free",
      searchesUsed: 0,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserSearchCount(userId: number): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    user.searchesUsed += 1;
    this.users.set(userId, user);
    return user;
  }
  
  async getUserSearchCount(userId: number): Promise<number> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error("User not found");
    }
    
    return user.searchesUsed;
  }
  
  // Search methods
  async createSearch(insertSearch: InsertSearch): Promise<Search> {
    const id = this.currentSearchId++;
    const search: Search = {
      ...insertSearch,
      id,
      createdAt: new Date()
    };
    this.searches.set(id, search);
    return search;
  }
  
  async getSearch(id: number): Promise<Search | undefined> {
    return this.searches.get(id);
  }
  
  async getUserSearches(userId: number): Promise<Search[]> {
    return Array.from(this.searches.values()).filter(
      (search) => search.userId === userId
    );
  }
  
  // Competitor methods
  async createCompetitor(insertCompetitor: InsertCompetitor): Promise<Competitor> {
    const id = this.currentCompetitorId++;
    const competitor: Competitor = {
      ...insertCompetitor,
      id
    };
    this.competitors.set(id, competitor);
    return competitor;
  }
  
  async getCompetitorsBySearch(searchId: number): Promise<Competitor[]> {
    return Array.from(this.competitors.values()).filter(
      (competitor) => competitor.searchId === searchId
    );
  }
  
  // Report methods
  async createReport(insertReport: InsertReport): Promise<Report> {
    const id = this.currentReportId++;
    const report: Report = {
      ...insertReport,
      id,
      createdAt: new Date()
    };
    this.reports.set(id, report);
    return report;
  }
  
  async getReport(id: number): Promise<Report | undefined> {
    return this.reports.get(id);
  }
  
  async getUserReports(userId: number): Promise<Report[]> {
    return Array.from(this.reports.values()).filter(
      (report) => report.userId === userId
    );
  }
}

export const storage = new MemStorage();
