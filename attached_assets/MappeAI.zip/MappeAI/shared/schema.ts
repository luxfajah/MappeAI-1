import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  name: text("name"),
  planType: text("plan_type").default("free").notNull(),
  searchesUsed: integer("searches_used").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Searches table
export const searches = pgTable("searches", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  businessName: text("business_name").notNull(),
  businessType: text("business_type").notNull(),
  location: text("location").notNull(),
  salesChannels: text("sales_channels").array(),
  keywords: text("keywords").array(),
  additionalInfo: json("additional_info"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Competitors table
export const competitors = pgTable("competitors", {
  id: serial("id").primaryKey(),
  searchId: integer("search_id").notNull(),
  name: text("name").notNull(),
  distance: text("distance"),
  rating: text("rating"),
  reviewCount: integer("review_count"),
  ticketPrice: text("ticket_price"),
  operationTime: text("operation_time"),
  salesChannels: text("sales_channels").array(),
  location: text("location"),
  placeId: text("place_id"),
  coordinates: json("coordinates"),
  links: json("links"),
  differentiators: text("differentiators").array(),
});

// Reports table
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  searchId: integer("search_id").notNull(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  summary: text("summary"),
  content: json("content").notNull(),
  selectedCompetitors: integer("selected_competitors").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

// Schema for user insertion
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  name: true,
});

// Schema for search insertion
export const insertSearchSchema = createInsertSchema(searches).pick({
  businessName: true,
  businessType: true,
  location: true,
  salesChannels: true,
  keywords: true,
  additionalInfo: true,
});

// Schema for competitor insertion
export const insertCompetitorSchema = createInsertSchema(competitors).omit({
  id: true,
});

// Schema for report insertion
export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  createdAt: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Search = typeof searches.$inferSelect;
export type InsertSearch = z.infer<typeof insertSearchSchema>;
export type Competitor = typeof competitors.$inferSelect;
export type InsertCompetitor = z.infer<typeof insertCompetitorSchema>;
export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;

// Plan limits
export const PLAN_LIMITS = {
  free: 5,
  intermediate: 30,
  advanced: 100
};
